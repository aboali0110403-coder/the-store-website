import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { BoutiqueProvider } from "./components/SiteShell";
import Home from "./pages/Home";
import Shop from "./pages/Shop";
import ProductDetail from "./pages/ProductDetail";
import Checkout from "./pages/Checkout";
import Story from "./pages/Story";
import CustomDesign from "./pages/CustomDesign";
import Admin from "./pages/Admin";
import Policies from "./pages/Policies";

function Router() {
  return <Switch>
    <Route path="/" component={Home} />
    <Route path="/shop" component={Shop} />
    <Route path="/shop/:slug" component={ProductDetail} />
    <Route path="/checkout" component={Checkout} />
    <Route path="/our-story" component={Story} />
    <Route path="/custom-design" component={CustomDesign} />
    <Route path="/policies/:slug" component={Policies} />
    <Route path="/admin" component={Admin} />
    <Route path="/404" component={NotFound} />
    <Route component={NotFound} />
  </Switch>;
}

function App() {
  return <ErrorBoundary><ThemeProvider defaultTheme="light"><TooltipProvider><Toaster /><BoutiqueProvider><Router /></BoutiqueProvider></TooltipProvider></ThemeProvider></ErrorBoundary>;
}

export default App;
