import { Heart, Plus } from "lucide-react";
import { Link } from "wouter";
import { formatPrice, type Product } from "@/lib/store";
import { useBoutique } from "@/components/SiteShell";

export function ProductCard({ product }: { product: Product }) {
  const { language, addToBag, toggleWishlist, isWishlisted } = useBoutique();
  const name = language === "ar" ? product.nameAr : product.name;
  const badge = product.badge === "New arrival" ? (language === "ar" ? "وصل حديثاً" : "New arrival") : (language === "ar" ? "حصري" : "Exclusive");
  return <article className="product-card">
    <div className="product-image-wrap">
      <Link href={`/shop/${product.slug}`} className="product-image-link" aria-label={name}><img src={product.image} alt={product.alt} /></Link>
      {product.badge && <span className="product-badge">{badge}</span>}
      <button className={`wishlist-button ${isWishlisted(product.id) ? "is-saved" : ""}`} onClick={() => toggleWishlist(product.id)} aria-label={`${language === "ar" ? "إضافة إلى المفضلة" : "Add to wishlist"}: ${name}`}><Heart size={17} fill={isWishlisted(product.id) ? "currentColor" : "none"} /></button>
      <Link className="quick-view" href={`/shop/${product.slug}`}>{language === "ar" ? "عرض القطعة" : "View piece"}</Link>
    </div>
    <div className="product-card-copy">
      <div className="product-card-heading"><div><Link href={`/shop/${product.slug}`}><h3>{name}</h3></Link><p>{language === "ar" ? product.categoryAr : product.category}</p></div><button className="add-mini" onClick={() => addToBag(product.id)} aria-label={`${language === "ar" ? "إضافة إلى الحقيبة" : "Add to bag"}: ${name}`}><Plus size={16} /></button></div>
      <div className="product-meta"><span>{formatPrice(product.price, language)}</span></div>
      <small className="image-illustration-note">{language === "ar" ? "رسم توضيحي — صورة القطعة الفعلية مطلوبة" : "Illustration — actual product photo required"}</small>
    </div>
  </article>;
}
