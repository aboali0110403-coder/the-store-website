import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";
import { fetchCatalog } from "@/lib/catalog";
import type { Product } from "@/lib/store";
import { Link, useLocation } from "wouter";
import { Heart, Menu, Search, ShoppingBag, Sparkles, X } from "lucide-react";
import {
  copy,
  formatPrice,
  readStorage,
  writeStorage,
  type CartItem,
  type Language,
} from "@/lib/store";
import { Button } from "@/components/ui/button";
import { storeConfig } from "@/lib/config";

const CART_KEY = "mero-cart";
const WISHLIST_KEY = "mero-wishlist";
const LANGUAGE_KEY = "mero-language";

type BoutiqueContextValue = {
  language: Language;
  setLanguage: (language: Language) => void;
  t: (typeof copy)[Language];
  cart: CartItem[];
  products: Product[];
  catalogLoading: boolean;
  catalogError: string | null;
  wishlist: string[];
  cartCount: number;
  cartTotal: number;
  addToBag: (productId: string, size?: string, color?: string) => void;
  updateQuantity: (productId: string, size: string, color: string, quantity: number) => void;
  removeFromBag: (productId: string, size: string, color: string) => void;
  toggleWishlist: (productId: string) => void;
  isWishlisted: (productId: string) => boolean;
  openBag: () => void;
};

const BoutiqueContext = createContext<BoutiqueContextValue | null>(null);

export function BoutiqueProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<Language>(() => {
    const stored = readStorage<Language | null>(LANGUAGE_KEY, null);
    if (stored) return stored;
    return typeof navigator !== "undefined" && navigator.language.toLowerCase().startsWith("ar") ? "ar" : "en";
  });
  const [cart, setCart] = useState<CartItem[]>(() => readStorage<CartItem[]>(CART_KEY, []));
  const [wishlist, setWishlist] = useState<string[]>(() => readStorage<string[]>(WISHLIST_KEY, []));
  const [bagOpen, setBagOpen] = useState(false);
  const catalogQuery = useQuery({ queryKey: ["public-catalog"], queryFn: fetchCatalog, staleTime: 60_000, retry: 1 });
  const catalog = catalogQuery.data ?? [];

  const setLanguage = (next: Language) => setLanguageState(next);

  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = language === "ar" ? "rtl" : "ltr";
    document.body.classList.toggle("rtl", language === "ar");
    writeStorage(LANGUAGE_KEY, language);
  }, [language]);

  useEffect(() => writeStorage(CART_KEY, cart), [cart]);
  useEffect(() => writeStorage(WISHLIST_KEY, wishlist), [wishlist]);

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const cartTotal = cart.reduce((sum, item) => {
    const product = catalog.find((entry) => entry.id === item.productId);
    return sum + (product?.price ?? 0) * item.quantity;
  }, 0);

  const addToBag = (productId: string, size?: string, color?: string) => {
    const product = catalog.find((item) => item.id === productId);
    if (!product) return;
    const chosenSize = size ?? product.sizes[0];
    const chosenColor = color ?? product.colors[0];
    setCart((current) => {
      const match = current.find((item) => item.productId === productId && item.size === chosenSize && item.color === chosenColor);
      if (match) {
        return current.map((item) => item === match ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...current, { productId, size: chosenSize, color: chosenColor, quantity: 1 }];
    });
    setBagOpen(true);
  };

  const updateQuantity = (productId: string, size: string, color: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromBag(productId, size, color);
      return;
    }
    setCart((current) => current.map((item) => item.productId === productId && item.size === size && item.color === color ? { ...item, quantity } : item));
  };

  const removeFromBag = (productId: string, size: string, color: string) => {
    setCart((current) => current.filter((item) => !(item.productId === productId && item.size === size && item.color === color)));
  };

  const toggleWishlist = (productId: string) => {
    setWishlist((current) => current.includes(productId) ? current.filter((id) => id !== productId) : [...current, productId]);
  };

  const value = useMemo<BoutiqueContextValue>(() => ({
    language,
    setLanguage,
    t: copy[language],
    cart,
    products: catalog,
    catalogLoading: catalogQuery.isLoading,
    catalogError: catalogQuery.error instanceof Error ? catalogQuery.error.message : null,
    wishlist,
    cartCount,
    cartTotal,
    addToBag,
    updateQuantity,
    removeFromBag,
    toggleWishlist,
    isWishlisted: (productId: string) => wishlist.includes(productId),
    openBag: () => setBagOpen(true),
  }), [language, cart, wishlist, cartCount, cartTotal, catalog, catalogQuery.isLoading, catalogQuery.error]);

  return (
    <BoutiqueContext.Provider value={value}>
      <div className="site-frame">
        <SiteHeader onOpenBag={() => setBagOpen(true)} />
        {children}
        <SiteFooter />
        <CartDrawer open={bagOpen} onClose={() => setBagOpen(false)} />
      </div>
    </BoutiqueContext.Provider>
  );
}

export function useBoutique() {
  const context = useContext(BoutiqueContext);
  if (!context) throw new Error("useBoutique must be used inside BoutiqueProvider");
  return context;
}

function SiteHeader({ onOpenBag }: { onOpenBag: () => void }) {
  const { t, language, setLanguage, cartCount, wishlist } = useBoutique();
  const [location] = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);

  const nav = [
    { href: "/", label: language === "ar" ? "الرئيسية" : "Home" },
    { href: "/shop", label: t.shopAll },
    { href: "/shop?category=Dresses", label: t.dresses },
    { href: "/shop?category=Abayas", label: t.abayas },
    { href: "/shop?category=Kaftans", label: t.kaftans },
    { href: "/shop?collection=signature", label: t.collections },
    { href: "/custom-design", label: language === "ar" ? "اطلبي تصميمك" : "Custom design" },
    { href: "/our-story", label: t.ourStory },
  ];

  return (
    <>
      <div className="announcement-bar">
        <Sparkles size={13} strokeWidth={1.5} />
        <span>{language === "ar" ? "اكتشفي فن التطريز اليدوي" : "Discover the art of hand embroidery"}</span>
        <span className="announcement-dot">·</span>
        <span className="announcement-secondary">{language === "ar" ? "كل غرزة تحكي قصة" : "Every stitch carries a story"}</span>
      </div>
      <header className="site-header">
        <div className="header-inner">
          <button className="icon-button mobile-menu-button" aria-label="Open menu" onClick={() => setMenuOpen(true)}><Menu size={19} /></button>
          <Link href="/" className="wordmark" onClick={() => setMenuOpen(false)}>
            <span>MERO</span>
            <small>B O U T I Q U E</small>
          </Link>
          <nav className={`main-nav ${menuOpen ? "is-open" : ""}`} aria-label="Primary navigation">
            <div className="mobile-nav-top">
              <span className="eyebrow">MERO BOUTIQUE</span>
              <button className="icon-button" aria-label="Close menu" onClick={() => setMenuOpen(false)}><X size={19} /></button>
            </div>
            {nav.map((item) => (
              <Link key={item.href} href={item.href} className={location === item.href ? "active" : ""} onClick={() => setMenuOpen(false)}>{item.label}</Link>
            ))}
          </nav>
          {menuOpen && <button className="menu-backdrop" aria-label="Close navigation" onClick={() => setMenuOpen(false)} />}
          <div className="header-actions">
            <Link className="icon-button desktop-only" href="/shop" aria-label={t.search}><Search size={18} /></Link>
            <Link className="icon-button wishlist-link" href="/shop?wishlist=true" aria-label={t.wishlist}><Heart size={18} fill={wishlist.length ? "currentColor" : "none"} /><span className="action-count">{wishlist.length}</span></Link>
            <button className="icon-button bag-button" aria-label={t.bag} onClick={onOpenBag}><ShoppingBag size={18} /><span className="action-count">{cartCount}</span></button>
            <button className="language-toggle" onClick={() => setLanguage(language === "en" ? "ar" : "en")} aria-label="Switch language">{language === "en" ? "ع" : "EN"}</button>
          </div>
        </div>
      </header>
    </>
  );
}

function CartDrawer({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { cart, cartTotal, language, updateQuantity, removeFromBag, t, products } = useBoutique();
  if (!open) return null;
  return (
    <div className="drawer-layer" role="dialog" aria-modal="true" aria-label={t.bag}>
      <button className="drawer-overlay" aria-label="Close shopping bag" onClick={onClose} />
      <aside className="cart-drawer">
        <div className="drawer-header">
          <div><span className="eyebrow">MERO BOUTIQUE</span><h2>{t.bag}</h2></div>
          <button className="icon-button" onClick={onClose} aria-label="Close shopping bag"><X size={20} /></button>
        </div>
        {cart.length === 0 ? (
          <div className="empty-state"><ShoppingBag size={26} strokeWidth={1.2} /><p>{language === "ar" ? "حقيبتك فارغة حالياً." : "Your bag is currently empty."}</p><Link href="/shop" className="text-link" onClick={onClose}>{t.explore}</Link></div>
        ) : (
          <>
            <div className="cart-items">
              {cart.map((item) => {
                const product = products.find((entry) => entry.id === item.productId);
                if (!product) return null;
                return <div className="cart-item" key={`${item.productId}-${item.size}-${item.color}`}>
                  <img src={product.image} alt={product.alt} />
                  <div className="cart-item-copy">
                    <div className="cart-item-top"><div><h3>{language === "ar" ? product.nameAr : product.name}</h3><p>{item.size} · {item.color}</p></div><button className="remove-button" aria-label="Remove item" onClick={() => removeFromBag(item.productId, item.size, item.color)}>×</button></div>
                    <div className="cart-item-bottom"><span>{formatPrice(product.price, language)}</span><div className="quantity-control"><button onClick={() => updateQuantity(item.productId, item.size, item.color, item.quantity - 1)} aria-label="Decrease quantity">−</button><span>{item.quantity}</span><button onClick={() => updateQuantity(item.productId, item.size, item.color, item.quantity + 1)} aria-label="Increase quantity">+</button></div></div>
                  </div>
                </div>;
              })}
            </div>
            <div className="drawer-summary"><div><span>{language === "ar" ? "الإجمالي الفرعي" : "Subtotal"}</span><strong>{formatPrice(cartTotal, language)}</strong></div><p>{language === "ar" ? "يتم احتساب الشحن عند إتمام الطلب." : "Shipping is calculated at checkout."}</p><Link className="solid-button full-width" href="/checkout" onClick={onClose}>{language === "ar" ? "إتمام الطلب" : "Proceed to checkout"}</Link></div>
          </>
        )}
      </aside>
    </div>
  );
}

function SiteFooter() {
  const { language, t } = useBoutique();
  return <footer className="site-footer">
    <div className="footer-inner">
      <div className="footer-brand"><Link href="/" className="wordmark wordmark-light"><span>MERO</span><small>B O U T I Q U E</small></Link><p>{language === "ar" ? "أزياء مصرية معاصرة تحمل روح التطريز." : "Contemporary Egyptian fashion with the soul of embroidery."}</p><div className="social-links">{storeConfig.instagramUrl && <a href={storeConfig.instagramUrl} target="_blank" rel="noreferrer">Instagram</a>}{storeConfig.whatsappNumber && <a href={`https://wa.me/${storeConfig.whatsappNumber}`} target="_blank" rel="noreferrer">WhatsApp</a>}</div></div>
      <div className="footer-column"><span className="footer-label">{language === "ar" ? "تسوقي" : "Shop"}</span><Link href="/shop">{t.shopAll}</Link><Link href="/shop?category=Dresses">{t.dresses}</Link><Link href="/shop?category=Abayas">{t.abayas}</Link><Link href="/shop?category=Kaftans">{t.kaftans}</Link><Link href="/shop?collection=signature">{t.collections}</Link></div>
      <div className="footer-column"><span className="footer-label">{language === "ar" ? "ميرو" : "Mero"}</span><Link href="/our-story">{t.ourStory}</Link><Link href="/our-story#craft">{language === "ar" ? "حرفتنا" : "Our craft"}</Link>{storeConfig.contactEmail && <a href={`mailto:${storeConfig.contactEmail}`}>{language === "ar" ? "تواصلي معنا" : "Contact us"}</a>}<Link href="/shop">{language === "ar" ? "دليل المقاسات" : "Size guide"}</Link></div>
      <div className="footer-column"><span className="footer-label">{language === "ar" ? "المساعدة" : "Care"}</span><Link href="/policies/shipping">{language === "ar" ? "سياسة الشحن" : "Shipping policy"}</Link><Link href="/policies/returns">{language === "ar" ? "الاستبدال والإرجاع" : "Returns & exchanges"}</Link><Link href="/policies/custom-orders">{language === "ar" ? "التصميمات الخاصة" : "Custom orders"}</Link><Link href="/policies/payment">{language === "ar" ? "سياسة الدفع" : "Payment policy"}</Link><Link href="/policies/privacy">{language === "ar" ? "الخصوصية" : "Privacy policy"}</Link><Link href="/policies/terms">{language === "ar" ? "الشروط والأحكام" : "Terms & conditions"}</Link></div>
    </div>
    <div className="footer-bottom"><span>© {new Date().getFullYear()} Mero Boutique</span><span>{language === "ar" ? "صُنع بحب في مصر" : "Made with care in Egypt"}</span></div>
  </footer>;
}
