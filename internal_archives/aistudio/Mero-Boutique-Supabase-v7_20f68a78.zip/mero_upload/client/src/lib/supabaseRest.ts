import { supabaseConfig } from "@/lib/config";

export async function supabaseRpc<T>(functionName: string, args: Record<string, unknown>): Promise<T> {
  if (!supabaseConfig.enabled) throw new Error("Supabase is not configured for this deployment.");
  const response = await fetch(`${supabaseConfig.url}/rest/v1/rpc/${functionName}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      apikey: supabaseConfig.publishableKey,
      Authorization: `Bearer ${supabaseConfig.publishableKey}`,
    },
    body: JSON.stringify(args),
  });
  const payload = await response.json().catch(() => null);
  if (!response.ok) {
    const message = payload?.message || payload?.details || "The request could not be saved.";
    throw new Error(message);
  }
  return payload as T;
}
