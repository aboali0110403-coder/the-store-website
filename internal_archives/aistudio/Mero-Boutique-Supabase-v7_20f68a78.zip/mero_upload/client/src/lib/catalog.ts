import { supabaseConfig } from "@/lib/config";
import type { Product } from "@/lib/store";

type ProductRow = {
  id: string; slug: string; name_en: string; name_ar: string; category: string; category_ar: string;
  description_en: string | null; description_ar: string | null; fabric_en: string | null; fabric_ar: string | null;
  embroidery_en: string | null; embroidery_ar: string | null; price_egp: number | string; compare_at_egp: number | string | null;
  image_url: string | null; image_alt: string | null; production_type: "ready" | "made_to_order" | "limited";
  sizes: string[] | null; colors: string[] | null; stock: number; is_published: boolean; is_featured: boolean;
};

function mapProduct(row: ProductRow): Product {
  const categoryMap: Record<string, Product["category"]> = { Dresses: "Dresses", Abayas: "Abayas", Kaftans: "Kaftans", Tops: "Tops", Sets: "Sets", "Exclusive Pieces": "Exclusive Pieces" };
  return {
    id: row.id, slug: row.slug, name: row.name_en, nameAr: row.name_ar,
    category: categoryMap[row.category] ?? "Exclusive Pieces", categoryAr: row.category_ar,
    price: Number(row.price_egp), compareAt: row.compare_at_egp == null ? undefined : Number(row.compare_at_egp),
    image: row.image_url || "/products/embroidered-dress.svg", alt: row.image_alt || row.name_en,
    description: row.description_en || "", descriptionAr: row.description_ar || "",
    fabric: row.fabric_en || "", fabricAr: row.fabric_ar || "", technique: row.embroidery_en || "", techniqueAr: row.embroidery_ar || "",
    production: row.production_type === "made_to_order" ? "made-to-order" : row.production_type,
    sizes: row.sizes || [], colors: row.colors || [], stock: row.stock,
    delivery: row.production_type === "ready" ? "Availability confirmed by the boutique" : "Production timing confirmed after review",
    deliveryAr: row.production_type === "ready" ? "يُؤكد التوافر من المتجر" : "تُحدد مدة التنفيذ بعد مراجعة الطلب",
    care: "", careAr: "", badge: row.is_featured ? "Exclusive" : undefined,
  };
}

export async function fetchCatalog(): Promise<Product[]> {
  if (!supabaseConfig.enabled) throw new Error("Supabase is not configured.");
  const response = await fetch(`${supabaseConfig.url}/rest/v1/products?select=*&is_published=eq.true&order=sort_order.asc,created_at.desc`, {
    headers: { apikey: supabaseConfig.publishableKey, Authorization: `Bearer ${supabaseConfig.publishableKey}` },
  });
  if (!response.ok) throw new Error("تعذر تحميل المنتجات من قاعدة البيانات.");
  const rows = await response.json() as ProductRow[];
  return rows.map(mapProduct);
}
