export type Language = "en" | "ar";
export type ProductionState = "ready" | "made-to-order" | "limited";

export type Product = {
  id: string;
  slug: string;
  name: string;
  nameAr: string;
  category: "Dresses" | "Abayas" | "Kaftans" | "Tops" | "Sets" | "Exclusive Pieces";
  categoryAr: string;
  price: number;
  compareAt?: number;
  image: string;
  alt: string;
  badge?: "New arrival" | "Exclusive";
  rating?: number;
  reviewCount?: number;
  description: string;
  descriptionAr: string;
  fabric: string;
  fabricAr: string;
  technique: string;
  techniqueAr: string;
  production: ProductionState;
  sizes: string[];
  colors: string[];
  stock: number;
  delivery: string;
  deliveryAr: string;
  care: string;
  careAr: string;
  isNew?: boolean;
};

export type CartItem = { productId: string; size: string; color: string; quantity: number };

export const imageUrls = {
  hero: "/products/embroidered-dress.svg",
  lavender: "/products/embroidered-dress.svg",
  heritage: "/products/heritage-abaya.svg",
  golden: "/products/golden-kaftan.svg",
  ivory: "/products/ivory-set.svg",
};

// Product data is loaded exclusively from the verified Supabase catalog.
export const products: Product[] = [];

export const categories = [
  { name: "Embroidered Dresses", nameAr: "فساتين مطرزة", filter: "Dresses", image: imageUrls.lavender },
  { name: "Abayas", nameAr: "عبايات", filter: "Abayas", image: imageUrls.heritage },
  { name: "Kaftans", nameAr: "قفاطين", filter: "Kaftans", image: imageUrls.golden },
  { name: "Embroidered Tops", nameAr: "قمصان مطرزة", filter: "Tops", image: imageUrls.ivory },
  { name: "Two-Piece Sets", nameAr: "أطقم من قطعتين", filter: "Sets", image: imageUrls.ivory },
  { name: "Exclusive Pieces", nameAr: "قطع حصرية", filter: "Exclusive Pieces", image: imageUrls.hero },
] as const;

export const collections = [
  { title: "The Heritage Collection", titleAr: "مجموعة التراث", text: "A quiet dialogue between heirloom motifs and modern silhouettes.", textAr: "حوار هادئ بين الزخارف التراثية والقصات العصرية.", image: imageUrls.heritage, count: "6 pieces" },
  { title: "Modern Elegance", titleAr: "الأناقة العصرية", text: "Clean lines, soft structure, and embroidery that speaks softly.", textAr: "خطوط نقية وتفاصيل ناعمة وتطريز بحضور هادئ.", image: imageUrls.ivory, count: "8 pieces" },
  { title: "Signature Embroidery", titleAr: "تطريز ميرو المميز", text: "The motifs that make a Mero piece unmistakably its own.", textAr: "الزخارف التي تمنح قطعة ميرو هويتها الخاصة.", image: imageUrls.golden, count: "4 pieces" },
];

export const copy = {
  en: {
    shopAll: "Shop all",
    dresses: "Dresses",
    abayas: "Abayas",
    kaftans: "Kaftans",
    collections: "Collections",
    ourStory: "Our story",
    explore: "Explore collection",
    craftCta: "Discover our craft",
    bag: "Shopping bag",
    wishlist: "Wishlist",
    search: "Search",
    selected: "Selected for you",
    exploreCollections: "Explore our collections",
    stories: "Stories from our customers",
    newsletter: "Stay close to the art.",
    newsletterText: "Be the first to discover our newest collections, exclusive designs, and stories behind the craft.",
    subscribe: "Subscribe",
    discover: "Discover the art of hand embroidery",
    wearArt: "Wear art. Celebrate craftsmanship.",
    heroText: "Discover the beauty of exclusive clothing, inspired by timeless embroidery and reimagined for the modern woman. Every stitch tells a story.",
  },
  ar: {
    shopAll: "تسوقي الكل",
    dresses: "فساتين",
    abayas: "عبايات",
    kaftans: "قفاطين",
    collections: "المجموعات",
    ourStory: "قصتنا",
    explore: "اكتشفي المجموعة",
    craftCta: "اكتشفي حرفتنا",
    bag: "حقيبة التسوق",
    wishlist: "المفضلة",
    search: "بحث",
    selected: "اختياراتنا لكِ",
    exploreCollections: "اكتشفي مجموعاتنا",
    stories: "حكايات من عميلاتنا",
    newsletter: "كوني قريبة من الفن.",
    newsletterText: "كوني أول من يكتشف مجموعاتنا الجديدة وتصاميمنا الحصرية وحكايات الحرفة وراء كل قطعة.",
    subscribe: "اشتركي",
    discover: "اكتشفي فن التطريز اليدوي",
    wearArt: "ارتدي الفن. واحتفلي بالحرفة.",
    heroText: "اكتشفي جمال الأزياء الحصرية المستوحاة من التطريز الخالد والمعاد تقديمه للمرأة العصرية. كل غرزة تحكي قصة.",
  },
} as const;

export const findProduct = (slug?: string) => products.find((product) => product.slug === slug);

export function formatPrice(amount: number, language: Language) {
  return new Intl.NumberFormat(language === "ar" ? "ar-EG" : "en-EG", {
    style: "currency",
    currency: "EGP",
    maximumFractionDigits: 0,
  }).format(amount);
}

export function readStorage<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const value = window.localStorage.getItem(key);
    return value ? (JSON.parse(value) as T) : fallback;
  } catch {
    return fallback;
  }
}

export function writeStorage<T>(key: string, value: T) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // Storage is optional; the shopping flow remains usable in memory.
  }
}
