const clean = (value: string | undefined) => (value ?? "").trim();

export const storeConfig = {
  whatsappNumber: clean(import.meta.env.VITE_STORE_WHATSAPP_NUMBER).replace(/\D/g, ""),
  catalogConfirmed: clean(import.meta.env.VITE_STORE_CATALOG_CONFIRMED).toLowerCase() === "true",
  contactEmail: clean(import.meta.env.VITE_STORE_CONTACT_EMAIL),
  instagramUrl: clean(import.meta.env.VITE_STORE_INSTAGRAM_URL),
};

export const supabaseConfig = {
  url: clean(import.meta.env.VITE_SUPABASE_URL).replace(/\/$/, ""),
  publishableKey: clean(import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY),
  get enabled() { return Boolean(this.url && this.publishableKey); },
};
