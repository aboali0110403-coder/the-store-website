import { useMemo, useState } from "react";
import { ChevronDown, Filter, Heart, Search, SlidersHorizontal, X } from "lucide-react";
import { Link, useLocation } from "wouter";
import { ProductCard } from "@/components/ProductCard";
import { useBoutique } from "@/components/SiteShell";
import type { Product } from "@/lib/store";

export default function Shop() {
  const { language, t, wishlist, products, catalogLoading, catalogError } = useBoutique();
  const [location] = useLocation();
  const params = new URLSearchParams(location.split("?")[1] ?? "");
  const categoryFromUrl = params.get("category") ?? "All pieces";
  const wishlistOnly = params.get("wishlist") === "true";
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState(categoryFromUrl);
  const [size, setSize] = useState("All sizes");
  const [color, setColor] = useState("All colors");
  const [price, setPrice] = useState("All prices");
  const [sort, setSort] = useState("Featured");
  const [filterOpen, setFilterOpen] = useState(false);

  const categories = ["All pieces", "Dresses", "Abayas", "Kaftans", "Tops", "Sets", "Exclusive Pieces"];
  const sizes = ["All sizes", "S", "M", "L", "XL"];
  const colors = ["All colors", "Lavender", "Deep rose", "Muted plum", "Warm ivory", "Black"];

  const visibleProducts = useMemo(() => {
    let result = products.filter((product) => {
      const matchesSearch = `${product.name} ${product.nameAr} ${product.category}`.toLowerCase().includes(search.toLowerCase());
      const matchesCategory = category === "All pieces" || product.category === category || (category === "Exclusive Pieces" && product.badge === "Exclusive");
      const matchesSize = size === "All sizes" || product.sizes.includes(size);
      const matchesColor = color === "All colors" || product.colors.some((entry) => entry.toLowerCase().includes(color.toLowerCase()));
      const matchesPrice = price === "All prices" || (price === "Under EGP 3,500" ? product.price < 3500 : product.price >= 3500);
      const matchesWishlist = !wishlistOnly || wishlist.includes(product.id);
      return matchesSearch && matchesCategory && matchesSize && matchesColor && matchesPrice && matchesWishlist;
    });
    if (sort === "Price: low to high") result = [...result].sort((a, b) => a.price - b.price);
    if (sort === "Price: high to low") result = [...result].sort((a, b) => b.price - a.price);
    if (sort === "Newest") result = [...result].sort((a, b) => Number(b.isNew) - Number(a.isNew));
    return result;
  }, [category, color, price, search, size, sort, wishlist, wishlistOnly]);

  const clearFilters = () => { setCategory("All pieces"); setSize("All sizes"); setColor("All colors"); setPrice("All prices"); setSearch(""); };

  return <main className="shop-page"><section className="page-intro"><div className="container page-intro-inner"><div><span className="eyebrow">MERO / SHOP</span><h1>{wishlistOnly ? (language === "ar" ? "المفضلة" : "Your wishlist") : (language === "ar" ? "المجموعة الكاملة" : "The complete edit")}</h1><p>{language === "ar" ? "قطع مصممة ببطء، بتفاصيل تستحق أن تُرى." : "Pieces designed slowly, with details worth looking at twice."}</p></div><span className="page-intro-note">{String(visibleProducts.length).padStart(2, "0")} {language === "ar" ? "قطع" : "pieces"}</span></div></section>
    <section className="container shop-content"><div className="shop-toolbar"><div className="search-field"><Search size={17} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder={language === "ar" ? "ابحثي في القطع" : "Search the collection"} aria-label="Search collection" />{search && <button onClick={() => setSearch("")} aria-label="Clear search"><X size={14} /></button>}</div><button className="filter-toggle" onClick={() => setFilterOpen((value) => !value)}><SlidersHorizontal size={16} />{language === "ar" ? "الفلاتر" : "Filters"}</button><label className="sort-select"><span>{language === "ar" ? "ترتيب" : "Sort"}</span><select value={sort} onChange={(event) => setSort(event.target.value)}><option>Featured</option><option>Newest</option><option>Price: low to high</option><option>Price: high to low</option></select><ChevronDown size={15} /></label></div>
      <div className={`shop-grid-layout ${filterOpen ? "filters-visible" : ""}`}><aside className="filter-panel"><div className="filter-panel-header"><span>{language === "ar" ? "تصفية" : "Filter by"}</span><button className="text-button" onClick={clearFilters}>{language === "ar" ? "مسح الكل" : "Clear all"}</button></div><FilterGroup title={language === "ar" ? "الفئة" : "Category"}><div className="filter-options">{categories.map((entry) => <button key={entry} className={category === entry ? "selected" : ""} onClick={() => setCategory(entry)}>{entry === "All pieces" ? (language === "ar" ? "كل القطع" : entry) : entry}</button>)}</div></FilterGroup><FilterGroup title={language === "ar" ? "المقاس" : "Size"}><div className="filter-options filter-pills">{sizes.map((entry) => <button key={entry} className={size === entry ? "selected" : ""} onClick={() => setSize(entry)}>{entry}</button>)}</div></FilterGroup><FilterGroup title={language === "ar" ? "اللون" : "Color"}><div className="filter-options">{colors.map((entry) => <button key={entry} className={color === entry ? "selected" : ""} onClick={() => setColor(entry)}>{entry}</button>)}</div></FilterGroup><FilterGroup title={language === "ar" ? "السعر" : "Price"}><div className="filter-options">{["All prices", "Under EGP 3,500", "EGP 3,500 and above"].map((entry) => <button key={entry} className={price === entry ? "selected" : ""} onClick={() => setPrice(entry)}>{entry}</button>)}</div></FilterGroup></aside><div className="shop-results">{catalogLoading ? <p className="empty-results">{language === "ar" ? "جارٍ تحميل المجموعة…" : "Loading the collection…"}</p> : catalogError ? <p className="empty-results">{catalogError}</p> : visibleProducts.length ? <div className="product-grid">{visibleProducts.map((product) => <ProductCard key={product.id} product={product} />)}</div> : <div className="empty-results"><Heart size={28} strokeWidth={1.2} /><h2>{language === "ar" ? "لا توجد قطع مطابقة" : "Nothing matches just yet"}</h2><p>{language === "ar" ? "جربي تغيير الفلاتر أو العودة إلى المجموعة الكاملة." : "Try another filter, or return to the complete edit."}</p><button className="solid-button" onClick={clearFilters}>{language === "ar" ? "مسح الفلاتر" : "Clear filters"}</button></div>}</div></div></section>
  </main>;
}

function FilterGroup({ title, children }: { title: string; children: React.ReactNode }) { return <div className="filter-group"><h3>{title}</h3>{children}</div>; }
