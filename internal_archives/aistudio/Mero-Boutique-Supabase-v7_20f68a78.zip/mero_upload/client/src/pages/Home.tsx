import { ArrowDownRight, ArrowUpRight, ChevronRight, Mail, Quote, Sparkles } from "lucide-react";
import { Link } from "wouter";
import { ProductCard } from "@/components/ProductCard";
import { useBoutique } from "@/components/SiteShell";
import { categories, collections, imageUrls } from "@/lib/store";
import { storeConfig } from "@/lib/config";

export default function Home() {
  const { language, t, products, catalogLoading } = useBoutique();

  return <main>
    <section className="hero-section">
      <div className="hero-copy">
        <span className="eyebrow"><span className="eyebrow-line" /> {language === "ar" ? "دار أزياء مصرية" : "An Egyptian fashion house"}</span>
        <h1>{t.wearArt}</h1>
        <p>{t.heroText}</p>
        <div className="hero-actions"><Link className="solid-button" href="/shop">{t.explore}<ArrowUpRight size={16} /></Link><Link className="text-link hero-story-link" href="/our-story">{t.craftCta}<ArrowDownRight size={16} /></Link><Link className="outline-button" href="/custom-design">{language === "ar" ? "اطلبي تصميمًا مخصصًا" : "Request a custom design"}<Sparkles size={15} /></Link></div>
        <div className="hero-note"><span className="hero-note-mark">M</span><span>{language === "ar" ? "كل غرزة تحكي قصة." : "Every stitch carries a story."}</span></div>
      </div>
      <div className="hero-image-wrap"><img src={imageUrls.hero} alt="Illustrative artwork for Mero Boutique fashion" /><div className="hero-image-caption"><span>{language === "ar" ? "رسم توضيحي — وليس صورة منتج فعلية" : "Illustration — not an actual product photo"}</span><span>01 / 04</span></div></div>
    </section>

    <section className="intro-strip"><div className="container intro-strip-inner"><span className="eyebrow">MERO / 01</span><p>{language === "ar" ? "نحتفي بالتقاء الحرفة المصرية مع التصميم المعاصر." : "Celebrating the meeting of Egyptian craft and contemporary design."}</p><Link href="/our-story" className="circle-arrow" aria-label="Read our story"><ArrowUpRight size={18} /></Link></div></section>

    <section className="section container categories-section" id="collections">
      <div className="section-heading-row"><div><span className="eyebrow">MERO / 02</span><h2>{t.exploreCollections}</h2></div><Link href="/shop" className="text-link">{t.shopAll}<ChevronRight size={15} /></Link></div>
      <div className="category-grid">{categories.map((category, index) => <Link key={category.name} href={`/shop?category=${encodeURIComponent(category.filter)}`} className="category-card"><div className="category-image"><img src={category.image} alt={category.name} /><span className="category-index">0{index + 1}</span></div><div className="category-label"><span>{language === "ar" ? category.nameAr : category.name}</span><ArrowUpRight size={15} /></div></Link>)}</div>
    </section>

    <section className="section container products-section" id="selected">
      <div className="section-heading-row"><div><span className="eyebrow">MERO / 03</span><h2>{t.selected}</h2></div><Link href="/shop" className="text-link">{language === "ar" ? "شاهدي الكل" : "View all pieces"}<ChevronRight size={15} /></Link></div>
      <div className="product-grid">{products.slice(0, 4).map((product) => <ProductCard key={product.id} product={product} />)}{!products.length && <p className="empty-results">{catalogLoading ? (language === "ar" ? "جارٍ تحميل القطع…" : "Loading pieces…") : (language === "ar" ? "تُضاف القطع المعتمدة قريبًا." : "Our approved pieces will appear here soon.")}</p>}</div>
    </section>

    <section className="craft-section" id="craft">
      <div className="container craft-layout"><div className="craft-main"><span className="eyebrow">MERO / 04</span><h2>{language === "ar" ? "حيث يلتقي التراث بالفن المعاصر." : "Where tradition meets modern art."}</h2><p>{language === "ar" ? "نؤمن في ميرو أن التفاصيل الصغيرة تصنع التصاميم الأكثر معنى. تجمع مجموعاتنا بين تأثيرات التطريز التقليدي والأزياء المعاصرة، لتصنع قطعاً تحمل شخصية وجمالاً خالداً." : "At Mero Boutique, we believe that the smallest details create the most meaningful designs. Our collections bring together traditional embroidery influences and contemporary fashion, creating pieces with character, individuality, and timeless beauty."}</p><Link href="/our-story" className="outline-button">{language === "ar" ? "اكتشفي قصتنا" : "Discover our story"}<ArrowUpRight size={16} /></Link></div><div className="craft-collage"><div className="craft-card craft-card-large"><img src={imageUrls.golden} alt="Embroidered kaftan detail" /><div><span>01</span><strong>{language === "ar" ? "إلهام تراثي" : "Traditional inspiration"}</strong><small>{language === "ar" ? "زخارف تحمل الذاكرة" : "Motifs that hold memory"}</small></div></div><div className="craft-card craft-card-small"><img src={imageUrls.ivory} alt="Contemporary embroidered silhouette" /><div><span>02</span><strong>{language === "ar" ? "تصميم معاصر" : "Contemporary design"}</strong><small>{language === "ar" ? "قصة جديدة للرمز" : "A new silhouette for the motif"}</small></div></div><div className="craft-card craft-card-note"><Sparkles size={18} /><p>{language === "ar" ? "تطريز يدوي، تطريز آلي، وتنفيذ مختلط — نوضح القصة وراء كل قطعة." : "Hand embroidery, machine embroidery, and mixed production — we make the story behind every piece clear."}</p></div></div></div>
    </section>

    <section className="section container collections-section"><div className="section-heading-row"><div><span className="eyebrow">MERO / 05</span><h2>{language === "ar" ? "مجموعات مختارة" : "The collection edit"}</h2></div><Link href="/shop?collection=all" className="text-link">{language === "ar" ? "استكشفي المجموعات" : "Explore collections"}<ChevronRight size={15} /></Link></div><div className="collection-rail">{collections.map((collection) => <article className="collection-card" key={collection.title}><img src={collection.image} alt={collection.title} /><div className="collection-overlay"><div><span className="collection-count">{collection.count}</span><h3>{language === "ar" ? collection.titleAr : collection.title}</h3><p>{language === "ar" ? collection.textAr : collection.text}</p></div><Link href="/shop" className="circle-arrow circle-arrow-light" aria-label={`Explore ${collection.title}`}><ArrowUpRight size={18} /></Link></div></article>)}</div></section>

    <section className="custom-design-promo"><div className="container custom-design-promo-inner"><div><span className="eyebrow">MERO / BESPOKE</span><h2>{language === "ar" ? "لديكِ تصميم في خيالك؟" : "Have a design in mind?"}</h2><p>{language === "ar" ? "ابتكري قطعة تعبّر عنكِ. شاركينا فكرتكِ واختاري التفاصيل والخامات والتطريز." : "Create a piece that feels like you. Share your idea and choose the details, fabrics and embroidery."}</p></div><Link className="solid-button" href="/custom-design">{language === "ar" ? "اطلبي تصميمك المخصص" : "Request your custom piece"}<ArrowUpRight size={16} /></Link></div></section>

    <section className="stats-band"><div className="container stats-inner"><div className="stats-intro"><span className="eyebrow eyebrow-light">MERO / 06</span><h2>{language === "ar" ? "الحرفة، موثقة." : "Craft, held to a standard."}</h2><p>{language === "ar" ? "الأرقام الحقيقية فقط تظهر هنا بعد إعداد بيانات العمل." : "Verified business numbers belong here once connected to the boutique database."}</p></div><div className="stats-grid"><div><strong>—</strong><span>{language === "ar" ? "عميلات سعيدات" : "Happy customers"}</span></div><div><strong>—</strong><span>{language === "ar" ? "تصاميم حصرية" : "Exclusive designs"}</span></div><div><strong>—</strong><span>{language === "ar" ? "مجموعات مطروحة" : "Collections released"}</span></div><div><strong>—</strong><span>{language === "ar" ? "رضا العميلات" : "Customer satisfaction"}</span></div></div></div></section>

    <section className="section container testimonials-section"><div className="section-heading-centered"><span className="eyebrow">MERO / 07</span><h2>{t.stories}</h2><p>{language === "ar" ? "نترك مساحة للأصوات الحقيقية — ستظهر المراجعات بعد اعتمادها من الإدارة." : "We leave room for real voices — reviews appear here after owner approval."}</p></div><div className="testimonials-grid"><TestimonialPlaceholder initials="MB" /><TestimonialPlaceholder initials="MB" /><TestimonialPlaceholder initials="MB" /></div></section>

    <section className="newsletter-section"><div className="container newsletter-inner"><div><span className="eyebrow">MERO / 08</span><h2>{t.newsletter}</h2><p>{t.newsletterText}</p></div>{storeConfig.contactEmail ? <a className="solid-button" href={`mailto:${storeConfig.contactEmail}?subject=${encodeURIComponent(language === "ar" ? "الاشتراك في نشرة ميرو" : "Mero Boutique newsletter")}`}>{language === "ar" ? "تواصلي للاشتراك" : "Join the mailing list"}<Mail size={15} /></a> : <p className="newsletter-coming-soon">{language === "ar" ? "التسجيل في النشرة البريدية سيتاح قريباً." : "Newsletter sign-up will be available soon."}</p>}</div></section>
  </main>;
}

function TestimonialPlaceholder({ initials }: { initials: string }) {
  const { language } = useBoutique();
  return <article className="testimonial-card"><Quote size={18} className="quote-mark" /><div className="testimonial-avatar">{initials}</div><div className="testimonial-stars">— — — — —</div><p>{language === "ar" ? "ستظهر هنا مراجعة حقيقية بعد اعتمادها من الإدارة." : "A genuine customer review will appear here after owner approval."}</p><span>{language === "ar" ? "مساحة مراجعة موثقة" : "Verified review space"}</span></article>;
}
