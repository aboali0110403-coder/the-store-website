import { useMemo, useState } from "react";
import { ArrowLeft, MessageCircle, ShoppingBag } from "lucide-react";
import { Link } from "wouter";
import { formatPrice } from "@/lib/store";
import { storeConfig, supabaseConfig } from "@/lib/config";
import { supabaseRpc } from "@/lib/supabaseRest";
import { useBoutique } from "@/components/SiteShell";

const governorates = [
  "Cairo", "Giza", "Alexandria", "Qalyubia", "Dakahlia", "Sharqia", "Gharbia", "Monufia",
  "Beheira", "Kafr El Sheikh", "Damietta", "Port Said", "Ismailia", "Suez", "North Sinai",
  "South Sinai", "Fayoum", "Beni Suef", "Minya", "Assiut", "Sohag", "Qena", "Luxor",
  "Aswan", "Red Sea", "New Valley", "Matrouh",
];

type FormState = { name: string; phone: string; email: string; governorate: string; area: string; address: string; notes: string };

export default function Checkout() {
  const { cart, cartTotal, language, updateQuantity, removeFromBag, products } = useBoutique();
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [saving, setSaving] = useState(false);
  const [acceptedPolicies, setAcceptedPolicies] = useState(false);
  const [form, setForm] = useState<FormState>({ name: "", phone: "", email: "", governorate: "", area: "", address: "", notes: "" });
  const lineItems = useMemo(
    () => cart.map((item) => ({ item, product: products.find((product) => product.id === item.productId) }))
      .filter((entry): entry is { item: typeof cart[number]; product: typeof products[number] } => Boolean(entry.product)),
    [cart, products],
  );
  const update = (key: keyof FormState, value: string) => setForm((current) => ({ ...current, [key]: value }));

  const submitOrder = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!form.name.trim() || !form.phone.trim() || !form.governorate || !form.area.trim() || !form.address.trim()) {
      setError(language === "ar" ? "يرجى استكمال الحقول المطلوبة." : "Please complete all required fields.");
      return;
    }
    if (!acceptedPolicies) {
      setError(language === "ar" ? "يرجى الموافقة على الشروط وسياسات المتجر للمتابعة." : "Please accept the store terms and policies to continue.");
      return;
    }
    if (!storeConfig.catalogConfirmed) {
      setError(language === "ar"
        ? "الكتالوج والأسعار والمخزون لم يتم اعتمادها بعد. لا يمكن إرسال طلبات حقيقية قبل مراجعتها وتأكيدها."
        : "The catalog, prices and stock have not been verified yet. Real order inquiries stay disabled until the boutique confirms them.");
      return;
    }
    if (!supabaseConfig.enabled) { setError(language === "ar" ? "نظام الطلبات غير متصل حاليًا." : "The order system is not connected yet."); return; }
    if (!lineItems.length || lineItems.length !== cart.length) { setError(language === "ar" ? "بعض القطع لم تعد متاحة. حدّثي الحقيبة وحاولي مجددًا." : "Some cart items are no longer available. Refresh your bag and try again."); return; }

    const orderLines = lineItems.map(({ item, product }) =>
      `• ${language === "ar" ? product.nameAr : product.name} | ${item.size} | ${item.color} | ${item.quantity} × ${formatPrice(product.price, language)}`,
    );
    const message = [
      language === "ar" ? "طلب جديد من متجر MERO BOUTIQUE" : "New order inquiry — MERO BOUTIQUE",
      "",
      ...orderLines,
      "",
      `${language === "ar" ? "الإجمالي قبل الشحن" : "Subtotal before shipping"}: ${formatPrice(cartTotal, language)}`,
      `${language === "ar" ? "الاسم" : "Name"}: ${form.name}`,
      `${language === "ar" ? "الهاتف" : "Phone"}: ${form.phone}`,
      `${language === "ar" ? "البريد الإلكتروني" : "Email"}: ${form.email || (language === "ar" ? "غير مذكور" : "Not provided")}`,
      `${language === "ar" ? "المحافظة" : "Governorate"}: ${form.governorate}`,
      `${language === "ar" ? "المنطقة" : "Area"}: ${form.area}`,
      `${language === "ar" ? "العنوان" : "Address"}: ${form.address}`,
      `${language === "ar" ? "ملاحظات" : "Notes"}: ${form.notes || "—"}`,
      "",
      language === "ar" ? "يرجى تأكيد توافر القطع وتكلفة الشحن والإجمالي النهائي." : "Please confirm item availability, shipping fee and final total.",
    ].join("\n");
    setSaving(true); setError(""); setSuccess("");
    try {
      const saved = await supabaseRpc<Array<{ order_id: string; order_number: string }> | { order_number?: string }>("submit_store_order", {
        p_customer_name: form.name, p_phone: form.phone, p_email: form.email || null,
        p_governorate: form.governorate, p_city_area: form.area, p_address: form.address,
        p_notes: form.notes || null, p_payment_method: "cash_on_delivery",
        p_items: lineItems.map(({ item }) => ({ product_id: item.productId, size: item.size, color: item.color, quantity: item.quantity })),
      });
      const orderNumber = Array.isArray(saved) ? saved[0]?.order_number : saved?.order_number;
      const finalMessage = `${message}\n${language === "ar" ? "رقم الطلب" : "Order reference"}: ${orderNumber || "Pending confirmation"}`;
      if (storeConfig.whatsappNumber) window.location.assign(`https://wa.me/${storeConfig.whatsappNumber}?text=${encodeURIComponent(finalMessage)}`);
      else setSuccess(language === "ar" ? `تم تسجيل طلبك بنجاح${orderNumber ? ` برقم ${orderNumber}` : ""}. سيتواصل معك فريق ميرو لتأكيد الشحن والتفاصيل.` : `Your order has been recorded${orderNumber ? ` (${orderNumber})` : ""}. Mero will contact you to confirm delivery and details.`);
    } catch (err) {
      setError(err instanceof Error ? err.message : (language === "ar" ? "تعذر تسجيل الطلب." : "Could not record the order."));
    } finally { setSaving(false); }
  };

  if (!cart.length) return <main className="empty-checkout"><ShoppingBag size={28} strokeWidth={1.2} /><span className="eyebrow">MERO BOUTIQUE</span><h1>{language === "ar" ? "حقيبتك فارغة" : "Your bag is empty"}</h1><p>{language === "ar" ? "أضيفي قطعة إلى حقيبتك قبل إتمام الطلب." : "Add a piece to your bag before starting checkout."}</p><Link href="/shop" className="solid-button">{language === "ar" ? "العودة إلى المتجر" : "Return to shop"}</Link></main>;

  return (
    <main className="checkout-page">
      <div className="container checkout-header">
        <Link href="/shop" className="text-link"><ArrowLeft size={15} />{language === "ar" ? "العودة للمتجر" : "Back to shop"}</Link>
        <div className="checkout-wordmark">MERO / CHECKOUT</div>
        <div className="secure-label"><MessageCircle size={14} />WhatsApp</div>
      </div>
      <div className="container checkout-layout">
        <form className="checkout-form" onSubmit={submitOrder}>
          <div className="checkout-section-title"><span className="eyebrow">01</span><div><h1>{language === "ar" ? "تفاصيل التوصيل" : "Delivery details"}</h1><p>{language === "ar" ? "سنرسل تفاصيل طلبك إلى فريق ميرو عبر واتساب لتأكيد التوافر والشحن." : "Your order details will be sent to Mero on WhatsApp for availability and delivery confirmation."}</p></div></div>
          <div className="form-grid">
            <Field label={language === "ar" ? "الاسم الكامل" : "Full name"} required value={form.name} onChange={(value) => update("name", value)} />
            <Field label={language === "ar" ? "رقم الهاتف" : "Phone number"} required type="tel" value={form.phone} onChange={(value) => update("phone", value)} />
            <Field label={language === "ar" ? "البريد الإلكتروني" : "Email (optional)"} type="email" value={form.email} onChange={(value) => update("email", value)} />
            <label className="form-field"><span>{language === "ar" ? "المحافظة" : "Governorate"}<em>*</em></span><select required value={form.governorate} onChange={(event) => update("governorate", event.target.value)}><option value="">{language === "ar" ? "اختاري المحافظة" : "Select governorate"}</option>{governorates.map((governorate) => <option key={governorate} value={governorate}>{governorate}</option>)}</select></label>
            <Field label={language === "ar" ? "المدينة أو المنطقة" : "City or area"} required value={form.area} onChange={(value) => update("area", value)} />
            <label className="form-field form-field-wide"><span>{language === "ar" ? "العنوان بالتفصيل" : "Detailed delivery address"}<em>*</em></span><textarea required rows={3} value={form.address} onChange={(event) => update("address", event.target.value)} placeholder={language === "ar" ? "الشارع، المبنى، الدور، الشقة" : "Street, building, floor, apartment"} /></label>
            <label className="form-field form-field-wide"><span>{language === "ar" ? "ملاحظات الطلب" : "Order notes"}</span><textarea rows={2} value={form.notes} onChange={(event) => update("notes", event.target.value)} placeholder={language === "ar" ? "أي تفاصيل تساعدنا في تجهيز الطلب أو التوصيل" : "Anything that helps us prepare or deliver your order"} /></label>
          </div>
          <div className="checkout-section-title payment-title"><span className="eyebrow">02</span><div><h2>{language === "ar" ? "تأكيد الطلب" : "Order confirmation"}</h2><p>{language === "ar" ? "لا يتم تحصيل أي مبلغ الآن. سنؤكد التوافر والشحن وطريقة الدفع معك قبل اعتماد الطلب." : "No payment is collected now. We’ll confirm availability, shipping and payment with you before accepting the order."}</p></div></div>
          <label className="policy-consent"><input type="checkbox" checked={acceptedPolicies} onChange={(event) => setAcceptedPolicies(event.target.checked)} /><span>{language === "ar" ? <>أوافق على <Link href="/policies/terms">الشروط والأحكام</Link> و<Link href="/policies/shipping">سياسة الشحن</Link> و<Link href="/policies/returns">الاستبدال والاسترجاع</Link> و<Link href="/policies/privacy">سياسة الخصوصية</Link>.</> : <>I agree to the <Link href="/policies/terms">Terms</Link>, <Link href="/policies/shipping">Shipping</Link>, <Link href="/policies/returns">Returns</Link> and <Link href="/policies/privacy">Privacy</Link> policies.</>}</span></label>
          {error && <p className="form-error" role="alert">{error}</p>}
          {success && <p className="form-success" role="status">{success}</p>}
          <button className="solid-button full-width checkout-submit" type="submit" disabled={saving}>{saving ? (language === "ar" ? "جارٍ تسجيل الطلب…" : "Recording order…") : (language === "ar" ? "تأكيد الطلب" : "Submit order")}<MessageCircle size={16} /></button>
          <p className="checkout-disclaimer">{language === "ar" ? "سيُحفظ الطلب أولًا في النظام، ثم يُفتح واتساب إن كان رقم المتجر الرسمي مُعدًا." : "Your order is saved first. WhatsApp opens afterward if the boutique number is configured."}</p>
        </form>
        <aside className="order-summary">
          <div className="summary-heading"><span className="eyebrow">MERO / BAG</span><h2>{language === "ar" ? "ملخص الطلب" : "Order summary"}</h2></div>
          <div className="summary-items">{lineItems.map(({ item, product }) => <div className="summary-item" key={`${item.productId}-${item.size}-${item.color}`}><img src={product.image} alt={product.alt} /><div><h3>{language === "ar" ? product.nameAr : product.name}</h3><p>{item.size} · {item.color}</p><div className="summary-item-bottom"><span>{formatPrice(product.price, language)}</span><div className="quantity-control"><button type="button" aria-label="Decrease quantity" onClick={() => updateQuantity(item.productId, item.size, item.color, item.quantity - 1)}>−</button><span>{item.quantity}</span><button type="button" aria-label="Increase quantity" onClick={() => updateQuantity(item.productId, item.size, item.color, item.quantity + 1)}>+</button></div></div><button className="summary-remove" type="button" onClick={() => removeFromBag(item.productId, item.size, item.color)}>{language === "ar" ? "حذف" : "Remove"}</button></div></div>)}</div>
          <div className="summary-totals"><div><span>{language === "ar" ? "الإجمالي الفرعي" : "Subtotal"}</span><strong>{formatPrice(cartTotal, language)}</strong></div><div><span>{language === "ar" ? "الشحن" : "Shipping"}</span><strong>{language === "ar" ? "يُحدد بعد مراجعة العنوان" : "Quoted after address review"}</strong></div><div className="summary-total"><span>{language === "ar" ? "الإجمالي النهائي" : "Final total"}</span><strong>{language === "ar" ? "يُؤكد عبر واتساب" : "Confirmed on WhatsApp"}</strong></div></div>
        </aside>
      </div>
    </main>
  );
}

function Field({ label, value, onChange, required, type = "text" }: { label: string; value: string; onChange: (value: string) => void; required?: boolean; type?: string }) {
  return <label className="form-field"><span>{label}{required && <em>*</em>}</span><input required={required} type={type} value={value} onChange={(event) => onChange(event.target.value)} /></label>;
}
