import { useState } from "react";
import { ArrowLeft, MessageCircle, Sparkles } from "lucide-react";
import { Link } from "wouter";
import { storeConfig, supabaseConfig } from "@/lib/config";
import { supabaseRpc } from "@/lib/supabaseRest";
import { useBoutique } from "@/components/SiteShell";

type RequestForm = { name: string; phone: string; garment: string; embroidery: string; colors: string; fabric: string; details: string; budget: string; deadline: string };
const initialForm: RequestForm = { name: "", phone: "", garment: "", embroidery: "", colors: "", fabric: "", details: "", budget: "", deadline: "" };

export default function CustomDesign() {
  const { language } = useBoutique();
  const ar = language === "ar";
  const [form, setForm] = useState<RequestForm>(initialForm);
  const [error, setError] = useState("");
  const [acceptedPolicy, setAcceptedPolicy] = useState(false);
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState("");
  const update = (key: keyof RequestForm, value: string) => setForm((current) => ({ ...current, [key]: value }));

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!form.name.trim() || !form.phone.trim() || !form.garment || !form.details.trim()) {
      setError(ar ? "يرجى استكمال الاسم ورقم الهاتف ونوع القطعة ووصف التصميم." : "Please complete your name, phone, garment type and design description.");
      return;
    }
    if (!acceptedPolicy) {
      setError(ar ? "يرجى الموافقة على سياسة التصميمات الخاصة للمتابعة." : "Please accept the custom order policy to continue.");
      return;
    }
    setError("");
    setSuccess("");
    const message = [
      ar ? "طلب تصميم مخصص جديد — MERO BOUTIQUE" : "New custom design request — MERO BOUTIQUE", "",
      `${ar ? "الاسم" : "Name"}: ${form.name}`, `${ar ? "رقم الهاتف" : "Phone"}: ${form.phone}`,
      `${ar ? "نوع القطعة" : "Garment"}: ${form.garment}`, `${ar ? "أسلوب التطريز" : "Embroidery style"}: ${form.embroidery || "—"}`,
      `${ar ? "الألوان" : "Colors"}: ${form.colors || "—"}`, `${ar ? "الخامة المفضلة" : "Preferred fabric"}: ${form.fabric || "—"}`,
      `${ar ? "تفاصيل التصميم" : "Design details"}: ${form.details}`, `${ar ? "الميزانية التقريبية" : "Approximate budget"}: ${form.budget || "—"}`,
      `${ar ? "الموعد المطلوب" : "Desired date"}: ${form.deadline || "—"}`, "",
      ar ? "يرجى مراجعة الطلب وتأكيد السعر والخامات ومدة التنفيذ." : "Please review and confirm the price, materials and production timeline.",
    ].join("\n");
    setSaving(true);
    try {
      if (supabaseConfig.enabled) {
        await supabaseRpc("submit_custom_design_request", {
          p_customer_name: form.name,
          p_phone: form.phone,
          p_email: null,
          p_garment_type: form.garment,
          p_preferred_fabric: form.fabric,
          p_preferred_colors: form.colors,
          p_embroidery_style: form.embroidery,
          p_size_details: null,
          p_description: form.details,
          p_reference_image_urls: [],
          p_target_budget_egp: form.budget ? Number(form.budget.replace(/[^0-9.]/g, "")) || null : null,
          p_needed_by: form.deadline || null,
        });
      }
      if (storeConfig.whatsappNumber) {
        window.location.assign(`https://wa.me/${storeConfig.whatsappNumber}?text=${encodeURIComponent(message)}`);
      } else if (supabaseConfig.enabled) {
        setSuccess(ar ? "تم استلام طلب التصميم وحفظه بنجاح. سيتواصل معك فريق ميرو بعد مراجعة التفاصيل." : "Your design request has been received and saved. Mero will contact you after reviewing the details.");
        setForm(initialForm);
      } else {
        setError(ar ? "لم يتم تفعيل قناة استقبال الطلبات بعد. يرجى المحاولة لاحقاً." : "Request submission is not configured yet. Please try again later.");
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : (ar ? "تعذر حفظ الطلب. يرجى المحاولة مرة أخرى." : "Could not save your request. Please try again."));
    } finally {
      setSaving(false);
    }
  };

  return <main className="custom-design-page">
    <div className="container custom-design-wrap">
      <Link href="/shop" className="text-link"><ArrowLeft size={15} />{ar ? "العودة إلى المتجر" : "Back to shop"}</Link>
      <header className="custom-design-heading"><span className="eyebrow"><Sparkles size={13} /> MERO / BESPOKE</span><h1>{ar ? "تصميمكِ، كما تتخيلينه." : "A piece imagined by you."}</h1><p>{ar ? "لديكِ فكرة مختلفة عن التصميمات المعروضة؟ يسعدنا تحويل رؤيتكِ إلى قطعة خاصة، بتفاصيل وخامات وتطريز يُختار بعناية." : "Have an idea beyond the pieces in our collection? Let us bring your vision to life with carefully selected fabrics, embroidery and details."}</p></header>
      <div className="custom-design-layout">
        <form className="checkout-form custom-design-form" onSubmit={submit}>
          <div className="checkout-section-title"><span className="eyebrow">01</span><div><h2>{ar ? "احكي لنا عن تصميمك" : "Tell us about your design"}</h2><p>{ar ? "كلما كانت التفاصيل أوضح، استطعنا مساعدتك بشكل أدق." : "A little detail helps us understand your vision."}</p></div></div>
          <div className="form-grid">
            <Field label={ar ? "الاسم" : "Your name"} required value={form.name} onChange={(v) => update("name", v)} />
            <Field label={ar ? "رقم الهاتف" : "Phone number"} required type="tel" value={form.phone} onChange={(v) => update("phone", v)} />
            <label className="form-field"><span>{ar ? "نوع القطعة" : "Garment type"}<em>*</em></span><select required value={form.garment} onChange={(e) => update("garment", e.target.value)}><option value="">{ar ? "اختاري نوع القطعة" : "Choose a garment"}</option>{(ar ? ["فستان", "عباية", "كفتان", "طقم", "بلوزة", "قطعة أخرى"] : ["Dress", "Abaya", "Kaftan", "Set", "Top", "Other"]).map((v) => <option key={v}>{v}</option>)}</select></label>
            <label className="form-field"><span>{ar ? "أسلوب التطريز" : "Embroidery style"}</span><select value={form.embroidery} onChange={(e) => update("embroidery", e.target.value)}><option value="">{ar ? "اختياري" : "Optional"}</option>{(ar ? ["يدوي", "آلي", "مختلط", "أترك الاختيار لميرو"] : ["Hand embroidery", "Machine embroidery", "Mixed", "Mero's recommendation"]).map((v) => <option key={v}>{v}</option>)}</select></label>
            <Field label={ar ? "الألوان المفضلة" : "Preferred colors"} value={form.colors} onChange={(v) => update("colors", v)} />
            <Field label={ar ? "الخامة المفضلة (إن وجدت)" : "Preferred fabric (if any)"} value={form.fabric} onChange={(v) => update("fabric", v)} />
            <label className="form-field form-field-wide"><span>{ar ? "صفي لنا التصميم والتفاصيل التي تتخيلينها" : "Describe your design and details"}<em>*</em></span><textarea required rows={5} value={form.details} onChange={(e) => update("details", e.target.value)} placeholder={ar ? "القصة، شكل التطريز، تفاصيل الأكمام، الطول، أو أي فكرة أخرى..." : "Silhouette, embroidery placement, sleeves, length, or any other details..."} /></label>
            <Field label={ar ? "الميزانية التقريبية (اختياري)" : "Approximate budget (optional)"} value={form.budget} onChange={(v) => update("budget", v)} />
            <Field label={ar ? "الموعد الذي تحتاجين القطعة فيه" : "When do you need it?"} value={form.deadline} onChange={(v) => update("deadline", v)} />
          </div>
          <div className="custom-deposit-note"><strong>{ar ? "تأكيد الحجز" : "Booking & deposit"}</strong><p>{ar ? "بعد مراجعة الفكرة والاتفاق على السعر والخامات، يتطلب بدء التنفيذ سداد مقدم قدره 30% من قيمة التصميم لتغطية جزء من تكلفة الخامات. يُسدد باقي المبلغ عند الاستلام. وفي حالة إلغاء الطلب بعد بدء التنفيذ، لا يُسترد المقدم." : "Once the design, materials and price are agreed, a 30% deposit is required before production begins to cover part of the material costs. The balance is due on delivery. The deposit is non-refundable if the order is cancelled after production has started."}</p></div>
          <label className="policy-consent"><input type="checkbox" checked={acceptedPolicy} onChange={(event) => setAcceptedPolicy(event.target.checked)} /><span>{ar ? <>قرأت وأوافق على <Link href="/policies/custom-orders">سياسة التصميمات والطلبات الخاصة</Link> و<Link href="/policies/privacy">سياسة الخصوصية</Link>.</> : <>I have read and agree to the <Link href="/policies/custom-orders">Custom Orders Policy</Link> and <Link href="/policies/privacy">Privacy Policy</Link>.</>}</span></label>
          {error && <p className="form-error" role="alert">{error}</p>}
          {success && <p className="form-success" role="status">{success}</p>}
          <button className="solid-button full-width checkout-submit" type="submit" disabled={saving}>{saving ? (ar ? "جارٍ حفظ الطلب…" : "Saving request…") : (ar ? "إرسال فكرة التصميم" : "Send my design idea")}<MessageCircle size={16} /></button>
          <p className="checkout-disclaimer">{ar ? "يمكنكِ إرسال صور مرجعية أو إلهام عبر واتساب بعد فتح المحادثة. إرسال الطلب لا يعني تأكيد السعر أو بدء التنفيذ؛ سنتواصل معكِ أولاً لمراجعة التفاصيل." : "You can share inspiration or reference photos in WhatsApp after the chat opens. Sending this inquiry does not confirm a price or start production; we will review the details with you first."}</p>
        </form>
        <aside className="custom-design-aside"><span className="eyebrow">MADE FOR YOU</span><h2>{ar ? "تفاصيلكِ تصنع الفرق." : "Your details make it yours."}</h2><p>{ar ? "التصميم المخصص مساحة لتعبّري عن ذوقكِ؛ نناقش معكِ الفكرة، ثم نحدد الخامات والتكلفة ومدة التنفيذ قبل أي التزام." : "Custom design is a chance to express your own style. We discuss the idea, then agree on materials, price and timing before any commitment."}</p><ul><li>{ar ? "اختيار القصة والتفاصيل" : "Choose the silhouette and details"}</li><li>{ar ? "تحديد الخامات والألوان" : "Select fabrics and colors"}</li><li>{ar ? "اختيار أسلوب التطريز" : "Choose the embroidery style"}</li><li>{ar ? "اعتماد السعر والمدة قبل التنفيذ" : "Approve price and timeline before production"}</li></ul></aside>
      </div>
    </div>
  </main>;
}

function Field({ label, value, onChange, required, type = "text" }: { label: string; value: string; onChange: (value: string) => void; required?: boolean; type?: string }) {
  return <label className="form-field"><span>{label}{required && <em>*</em>}</span><input required={required} type={type} value={value} onChange={(event) => onChange(event.target.value)} /></label>;
}
