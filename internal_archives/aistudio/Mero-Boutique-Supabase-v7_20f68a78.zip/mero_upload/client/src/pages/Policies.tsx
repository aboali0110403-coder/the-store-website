import { Link, useRoute } from "wouter";
import { ArrowLeft, ArrowRight, ShieldCheck } from "lucide-react";
import { useBoutique } from "@/components/SiteShell";

type Section = { title: string; paragraphs?: string[]; bullets?: string[] };
type Policy = { title: string; intro: string; sections: Section[] };

const arPolicies: Record<string, Policy> = {
  shipping: {
    title: "سياسة الشحن والتوصيل",
    intro: "نحرص على وصول كل قطعة إليكِ بعناية، ونوضح تفاصيل التوصيل قبل تأكيد الطلب.",
    sections: [
      { title: "مدة التجهيز والتوصيل", paragraphs: ["تختلف مدة التجهيز بحسب طبيعة القطعة؛ فالمنتجات الجاهزة تُجهّز للشحن بعد تأكيد الطلب، أما التصميمات المنفذة حسب الطلب فتحتاج إلى مدة تنفيذ يتم الاتفاق عليها مسبقاً.", "نؤكد معكِ موعد التوصيل التقديري قبل اعتماد الطلب، وقد تختلف المدة بحسب المحافظة وشركة الشحن والظروف الخارجة عن إرادتنا."] },
      { title: "تكلفة الشحن", paragraphs: ["تُحدد تكلفة الشحن وفقاً لعنوان التسليم والمحافظة وحجم الطلب، ويتم إبلاغكِ بها قبل تأكيد الطلب. لا تُعد تكلفة الشحن جزءاً من سعر المنتج إلا إذا تم توضيح ذلك صراحةً."] },
      { title: "استلام الطلب", bullets: ["يرجى التأكد من صحة رقم الهاتف والعنوان وتفاصيل الوصول عند تأكيد الطلب.", "يرجى فحص حالة الطرد عند الاستلام، والتواصل معنا سريعاً إذا لاحظتِ تلفاً ظاهراً أو اختلافاً عن الطلب.", "قد يتطلب تعذر التواصل أو عدم التواجد إعادة جدولة التسليم أو تحمل تكلفة شحن إضافية وفقاً لشركة الشحن."] },
    ],
  },
  returns: {
    title: "سياسة الاستبدال والاسترجاع",
    intro: "راحتكِ وثقتكِ مهمتان بالنسبة لنا. تسري السياسة التالية على القطع الجاهزة المتاحة للبيع، مع مراعاة الحقوق التي يكفلها القانون.",
    sections: [
      { title: "المدة المسموح بها", paragraphs: ["يمكن طلب استبدال أو استرجاع القطع الجاهزة خلال 14 يوماً من تاريخ استلامها دون إبداء أسباب، مع مراعاة الاستثناءات القانونية. وفي حالة وجود عيب أو عدم مطابقة للمواصفات المتفق عليها، يحق للعميلة طلب الاستبدال أو الاسترجاع خلال 30 يوماً من تاريخ الاستلام وفقاً للقانون. يُرجى التواصل معنا فوراً لتسجيل الطلب."] },
      { title: "حالة المنتج", bullets: ["أن يكون المنتج غير مستخدم أو مغسول أو متضرر.", "أن يكون بحالته الأصلية، مع الملحقات والتغليف الأصلي قدر الإمكان.", "قد نطلب صوراً توضح حالة المنتج قبل اعتماد الإجراء."] },
      { title: "تكاليف الشحن والاسترداد", paragraphs: ["تتم إجراءات الاستبدال أو الاسترجاع دون تحميل العميلة نفقات بالمخالفة لحقوقها القانونية. وفي حالة وجود عيب أو عدم مطابقة، يتم الاستبدال أو رد القيمة دون تكلفة إضافية وفقاً للقانون. وقد تنطبق استثناءات قانونية محددة بحسب طبيعة المنتج وحالته.", "تتم إعادة المبالغ بالطريقة المناسبة والمتاحة بعد استلام المنتج وفحصه، مع إبلاغكِ بالخطوات والمدة المتوقعة."] },
      { title: "التصميمات الخاصة", paragraphs: ["القطع التي يتم تنفيذها خصيصاً وفق طلب العميلة أو مقاساتها أو مواصفاتها لا تخضع للإرجاع أو الاستبدال لمجرد تغيير الرأي، بعد بدء التنفيذ؛ ولا يخل ذلك بحقوق العميلة القانونية عند وجود عيب أو عدم مطابقة للمواصفات المتفق عليها."] },
    ],
  },
  "custom-orders": {
    title: "سياسة التصميمات والطلبات الخاصة",
    intro: "كل تصميم مخصص يبدأ بفكرة، ثم يتحول إلى قطعة تُنفذ بعناية وفق التفاصيل التي نتفق عليها معكِ.",
    sections: [
      { title: "مراحل الطلب", bullets: ["ترسلين لنا فكرة التصميم والتفاصيل والصور المرجعية إن وجدت.", "نراجع إمكانية التنفيذ ونقترح الخامات والتطريز والتفاصيل المناسبة.", "نرسل لكِ السعر النهائي والمدة التقديرية وأي تفاصيل لازمة للموافقة.", "لا يبدأ التنفيذ إلا بعد موافقتكِ على التفاصيل وسداد المقدم."] },
      { title: "المقدم وسداد باقي القيمة", paragraphs: ["يُسدد مقدم بنسبة 30% من قيمة التصميم بعد الاتفاق النهائي، للمساهمة في تغطية تكاليف الخامات وبدء التجهيز. ويُسدد باقي المبلغ عند الاستلام. وتُعد القطع المصنوعة وفق مواصفات خاصة حددتها العميلة من الحالات التي قد ينطبق عليها استثناء حق العدول، متى كانت مطابقة للمواصفات المتفق عليها.", "إذا رغبتِ في تعديل التصميم بعد اعتماد التفاصيل وبدء التنفيذ، فقد يؤثر ذلك على التكلفة وموعد التسليم، ولا يتم أي تعديل إلا بعد الاتفاق معكِ."] },
      { title: "الإلغاء", paragraphs: ["إذا تم إلغاء الطلب بعد بدء التنفيذ، لا يُسترد المقدم المدفوع، نظراً لتخصيص الخامات والوقت والجهد للطلب. أما قبل بدء التنفيذ، فيتم التواصل لمراجعة حالة الطلب وأي تكاليف تم الالتزام بها بالفعل، مع مراعاة الحقوق القانونية."] },
      { title: "الصور المرجعية والنتيجة النهائية", paragraphs: ["تُستخدم الصور المرجعية لفهم الفكرة والاتجاه العام، وقد تختلف النتيجة النهائية اختلافاً طبيعياً بسبب توافر الخامات وطبيعة التنفيذ اليدوي أو اختلاف درجات الألوان بين الشاشات. نوضح أي اختلاف جوهري ونتفق عليه قبل بدء التنفيذ."] },
    ],
  },
  payment: {
    title: "سياسة الدفع",
    intro: "نوفر خيارات دفع واضحة، ويتم تأكيد المبلغ المستحق قبل اعتماد الطلب.",
    sections: [
      { title: "طرق الدفع", bullets: ["الدفع مقدماً وفق وسيلة الدفع التي يتم تأكيد توافرها عند الطلب.", "الدفع عند الاستلام للطلبات التي نؤكد إمكانية توفير هذه الخدمة لها."] },
      { title: "الطلبات المصممة خصيصاً", paragraphs: ["تتطلب التصميمات الخاصة مقدم حجز بنسبة 30% من قيمة التصميم بعد اعتماد السعر والتفاصيل، ولا يُعد الطلب مؤكداً أو يبدأ تنفيذه قبل استلام المقدم. يُسدد الرصيد المتبقي عند الاستلام."] },
      { title: "الشحن والمبالغ الإضافية", paragraphs: ["تُوضح تكلفة الشحن وأي رسوم إضافية قبل تأكيد الطلب. لا نفرض رسوماً غير موضحة أو متفق عليها مسبقاً."] },
    ],
  },
  privacy: {
    title: "سياسة الخصوصية",
    intro: "نحترم خصوصيتكِ ونتعامل مع بياناتكِ بالقدر اللازم للرد على استفساراتكِ وتنظيم طلباتكِ.",
    sections: [
      { title: "البيانات التي قد تشاركينها", paragraphs: ["قد تطلب عملية الاستفسار أو الطلب بيانات مثل الاسم ورقم الهاتف وعنوان التوصيل وتفاصيل المقاس والتصميم. لا تشاركي بيانات لا نحتاج إليها لإتمام الخدمة."] },
      { title: "كيف نستخدم البيانات", bullets: ["الرد على استفساراتكِ ومراجعة طلبات التصميم.", "تأكيد الطلب والتواصل بشأن التجهيز والتوصيل والاستبدال.", "تحسين تجربة المتجر ومعالجة المشكلات المتعلقة بالطلب."] },
      { title: "التواصل عبر خدمات خارجية", paragraphs: ["قد تنتقل البيانات التي تختارين إرسالها عبر واتساب إلى خدمة واتساب وتخضع لسياسة الخصوصية الخاصة بها. لا تدخلي بيانات الدفع الحساسة أو كلمات المرور في رسائل المحادثة."] },
      { title: "الاحتفاظ بالبيانات وحقوقكِ", paragraphs: ["في الوضع الحالي، لا ينشئ الموقع حساباً للعميلة ولا يحفظ نماذج الطلبات في قاعدة بيانات للمتجر. عند اختياركِ المتابعة عبر واتساب، تتم معالجة البيانات التي ترسلينها من خلال خدمة واتساب وحساب المتجر عليها. وأي سجلات يحتفظ بها المتجر تُستخدم بالقدر اللازم لمتابعة الطلب والالتزامات القانونية. يمكنكِ التواصل معنا للاستفسار عن بياناتكِ أو طلب تصحيحها، مع مراعاة ما يلزم الاحتفاظ به قانوناً."] },
      { title: "ملفات الارتباط والتخزين المحلي", paragraphs: ["قد يحفظ الموقع تفضيلات اللغة ومحتويات حقيبة التسوق وقائمة الأمنيات على جهازكِ لتحسين الاستخدام. حذف بيانات المتصفح قد يؤدي إلى فقدان هذه التفضيلات."] },
    ],
  },
  terms: {
    title: "الشروط والأحكام",
    intro: "باستخدامكِ الموقع أو تقديم طلب، فإنكِ تقرين بقراءة الشروط التالية وفهمها.",
    sections: [
      { title: "المعلومات والأسعار", paragraphs: ["نبذل جهداً لتقديم وصف دقيق للمنتجات، لكن الألوان قد تبدو مختلفة قليلاً باختلاف الشاشات والإضاءة. الأسعار قابلة للاختلاف بحسب الخامات والتفاصيل، ولا يصبح السعر نهائياً إلا بعد تأكيده معكِ."] },
      { title: "الطلب وتأكيده", paragraphs: ["إضافة منتج إلى الحقيبة أو إرسال استفسار لا يعني وحده قبول الطلب. يصبح الطلب مؤكداً بعد مراجعة التوافر والتفاصيل والسعر وطريقة الدفع والتوصيل وإبلاغكِ بالتأكيد."] },
      { title: "التصميمات المخصصة", paragraphs: ["تخضع الطلبات الخاصة للمواصفات والمدة والمقدم المتفق عليها قبل التنفيذ، وتُراجع أي تغييرات لاحقة من حيث التكلفة والوقت قبل اعتمادها."] },
      { title: "حقوق الملكية", paragraphs: ["المحتوى والنصوص والعناصر البصرية والعلامات المنشورة على الموقع مخصصة لـ Mero Boutique أو مستخدمة بإذن، ولا يجوز نسخها أو استخدامها تجارياً دون موافقة صاحب الحق."] },
      { title: "التحديثات والحقوق القانونية", paragraphs: ["قد نحدّث هذه الشروط عند الحاجة، وتُنشر النسخة السارية على هذه الصفحة. لا تهدف هذه الشروط إلى الانتقاص من أي حق مقرر للعميلة بموجب القوانين المصرية واجبة التطبيق."] },
    ],
  },
};

const enPolicies: Record<string, Policy> = {
  shipping: { title: "Shipping & delivery", intro: "We prepare every piece with care and confirm delivery details before your order is finalized.", sections: [
    { title: "Preparation and delivery time", paragraphs: ["Ready-to-wear pieces are prepared after order confirmation. Made-to-order pieces require production time agreed with you in advance.", "Estimated delivery depends on your governorate, courier availability and circumstances beyond our control. We will communicate the expected timeline before confirming the order."] },
    { title: "Shipping fees", paragraphs: ["Shipping fees depend on the delivery address and parcel details. The applicable fee will be shared before you confirm the order."] },
    { title: "Receiving your order", bullets: ["Please provide an accurate phone number and delivery address.", "Contact us promptly if the parcel appears damaged or differs from your confirmed order.", "Missed deliveries may require rescheduling or additional courier charges."] },
  ] },
  returns: { title: "Returns & exchanges", intro: "Your confidence matters. This policy applies to ready-to-wear items offered for immediate sale, subject to applicable consumer rights.", sections: [
    { title: "Time window", paragraphs: ["You may request a return or exchange for ready-to-wear items within 14 days of receipt without stating a reason, subject to statutory exceptions. For defective or non-conforming items, the applicable period is 30 days from receipt. Please contact us promptly to register your request."] },
    { title: "Item condition", bullets: ["Items must be unused, unwashed and undamaged.", "Items should be returned in their original condition with accessories and packaging where possible.", "We may request photos before approving the process."] },
    { title: "Shipping and refunds", paragraphs: ["Returns and exchanges will be handled without charging the customer expenses contrary to statutory rights. Defective or non-conforming items will be addressed without additional cost as required by law. Specific statutory exceptions may apply depending on the item and its condition.", "Refunds are processed using an agreed available method after the item is received and inspected."] },
    { title: "Custom-made items", paragraphs: ["Custom-made items produced to the customer’s specific specifications may fall within the statutory exception to change-of-mind returns when they conform to the agreed specifications. This does not limit statutory rights relating to defects or failure to match agreed specifications."] },
  ] },
  "custom-orders": { title: "Custom & made-to-order policy", intro: "Your idea guides the process; we agree on the details before production begins.", sections: [
    { title: "How it works", bullets: ["Send your idea, details and any reference images.", "We review feasibility and discuss fabrics, embroidery and finishing.", "We confirm the final price and estimated production time.", "Production begins only after your approval and deposit payment."] },
    { title: "Deposit and balance", paragraphs: ["A 30% deposit is required after the final design and price are agreed. It contributes toward material costs and production preparation. The remaining balance is due on delivery.", "Changes requested after approval may affect the price and timeline and must be agreed before proceeding."] },
    { title: "Cancellation", paragraphs: ["If an order is cancelled after production has started, the deposit is generally non-refundable because materials, time and work have been allocated to the order, subject always to statutory consumer rights, including rights relating to defects or non-conformity. Requests made before production starts will be reviewed based on costs already committed and applicable law."] },
    { title: "References and final result", paragraphs: ["Reference images communicate the desired direction. Minor differences may occur due to material availability, handmade techniques or screen color settings. Any material difference will be discussed before production."] },
  ] },
  payment: { title: "Payment policy", intro: "Payment options and the total amount due are confirmed before an order is accepted.", sections: [
    { title: "Available methods", bullets: ["Advance payment through a method confirmed at the time of ordering.", "Cash on delivery for orders where this service is confirmed as available."] },
    { title: "Custom orders", paragraphs: ["Custom orders require a 30% deposit after the design and price are approved. Production does not begin until the deposit is received. The balance is due on delivery."] },
    { title: "Shipping and additional fees", paragraphs: ["Shipping fees and any additional charges are disclosed before order confirmation. No undisclosed fees will be added."] },
  ] },
  privacy: { title: "Privacy policy", intro: "We respect your privacy and use the information you choose to share only as needed to respond and manage your orders.", sections: [
    { title: "Information you may provide", paragraphs: ["Depending on your enquiry or order, we may ask for your name, phone number, delivery address, sizing and design details. Please do not share information that is not needed for the service."] },
    { title: "How information is used", bullets: ["Responding to enquiries and reviewing custom design requests.", "Confirming orders and coordinating production, delivery and after-sales requests.", "Improving the store experience and resolving order issues."] },
    { title: "Third-party communication services", paragraphs: ["Information you choose to send through WhatsApp is processed by WhatsApp and subject to its own privacy policy. Do not send payment credentials or passwords in chat messages."] },
    { title: "Retention and your choices", paragraphs: ["When you submit an order or custom-design request, the information entered in the form is transmitted to the boutique’s Supabase database so the team can review and manage the request. If WhatsApp is configured, a prepared message may also open so you can contact the boutique; the message is not sent until you press Send. Records are retained only as needed for order management, customer service and legal obligations. You may contact the boutique to ask about or correct information, subject to lawful retention requirements."] },
    { title: "Local storage", paragraphs: ["The site may store language preferences, bag contents and wishlist items locally on your device. Clearing browser data may remove these preferences."] },
  ] },
  terms: { title: "Terms & conditions", intro: "By using this website or placing an enquiry, you agree to the following terms.", sections: [
    { title: "Product information and prices", paragraphs: ["We aim to describe products accurately, but colors may vary by screen and lighting. Displayed catalog prices apply to the listed product and selected options. Custom-design prices are quoted individually after materials and specifications are agreed."] },
    { title: "Order confirmation", paragraphs: ["Adding an item to your bag or sending an enquiry does not by itself constitute acceptance. We confirm availability, specifications, price, payment and delivery details before accepting an order."] },
    { title: "Custom orders", paragraphs: ["Custom orders follow the specifications, timeline and deposit agreed before production. Later changes must be reviewed for price and timing before approval."] },
    { title: "Intellectual property", paragraphs: ["Website content, copy, visual elements and brand assets belong to Mero Boutique or are used with permission and may not be commercially reused without the rights holder's consent."] },
    { title: "Updates and legal rights", paragraphs: ["We may update these terms when needed. Nothing here is intended to limit consumer rights under applicable Egyptian law."] },
  ] },
};

const policyLinks = [
  ["shipping", "الشحن والتوصيل", "Shipping"],
  ["returns", "الاستبدال والاسترجاع", "Returns & exchanges"],
  ["custom-orders", "التصميمات الخاصة", "Custom orders"],
  ["payment", "الدفع", "Payment"],
  ["privacy", "الخصوصية", "Privacy"],
  ["terms", "الشروط والأحكام", "Terms"],
] as const;

export default function Policies() {
  const { language } = useBoutique();
  const ar = language === "ar";
  const [, params] = useRoute("/policies/:slug");
  const slug = params?.slug ?? "shipping";
  const policy = (ar ? arPolicies : enPolicies)[slug] ?? (ar ? arPolicies : enPolicies).shipping;
  const BackIcon = ar ? ArrowRight : ArrowLeft;
  return <main className="policy-page"><div className="container policy-wrap">
    <Link href="/" className="text-link policy-back"><BackIcon size={15} />{ar ? "العودة للرئيسية" : "Back to home"}</Link>
    <header className="policy-heading"><span className="eyebrow"><ShieldCheck size={13} /> MERO / CUSTOMER CARE</span><h1>{policy.title}</h1><p>{policy.intro}</p></header>
    <div className="policy-layout"><nav className="policy-nav" aria-label={ar ? "صفحات السياسات" : "Policy pages"}><span className="footer-label">{ar ? "معلومات تهمك" : "INFORMATION"}</span>{policyLinks.map(([key, arLabel, enLabel]) => <Link key={key} href={`/policies/${key}`} className={slug === key ? "active" : ""}>{ar ? arLabel : enLabel}</Link>)}</nav>
      <article className="policy-content">{policy.sections.map((section, index) => <section className="policy-section" key={section.title}><span className="eyebrow">{String(index + 1).padStart(2, "0")}</span><h2>{section.title}</h2>{section.paragraphs?.map((paragraph) => <p key={paragraph}>{paragraph}</p>)}{section.bullets && <ul>{section.bullets.map((bullet) => <li key={bullet}>{bullet}</li>)}</ul>}</section>)}
        <div className="policy-contact"><strong>{ar ? "هل لديكِ استفسار؟" : "Need help?"}</strong><p>{ar ? "يسعدنا مساعدتكِ في فهم أي تفصيل قبل تأكيد طلبكِ." : "We are happy to clarify anything before you confirm your order."}</p><Link href="/custom-design" className="text-link">{ar ? "اطلبي تصميمكِ المخصص" : "Request a custom design"} <ArrowLeft size={14} /></Link></div>
      </article></div>
    <p className="policy-note">{ar ? "آخر تحديث: نوفمبر 2026. هذه السياسات إرشادية، ويجب مراجعتها قانونياً واعتمادها بما يتوافق مع إجراءات المتجر والقوانين المصرية قبل الإطلاق التجاري." : "Last updated: November 2026. These policies should be reviewed by Egyptian counsel against the store's actual operating procedures and applicable law before commercial launch."}</p>
  </div></main>;
}
