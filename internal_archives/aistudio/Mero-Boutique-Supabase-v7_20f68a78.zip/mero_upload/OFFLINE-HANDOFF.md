# Mero Boutique — current handoff (without GitHub)

This package is the working source snapshot. GitHub is not required to continue development.

## Connected services
- Supabase project: `mero-boutique`
- Project ref: `pvvsvxdqjguemptocvcs`
- Region: `eu-central-1`
- API URL: `https://pvvsvxdqjguemptocvcs.supabase.co`
- Frontend publishable key is in `.env.example`; it is designed for browser use and is protected by RLS.
- Database tables: `products`, `orders`, `order_items`, `custom_design_requests`, `admin_users`.
- Storage bucket: `product-images`.

## Important current status
- Supabase schema and customer submission RPCs exist in the live project.
- Custom design form submits to Supabase when configured.
- No verified product catalog has been entered. Do not publish the illustrative local sample products or their sample EGP prices as real offers.
- The storefront's cart/catalog still contains local demonstration data and must be replaced with live `products` queries before public launch.
- The admin page still depends on the starter platform's legacy authentication; Supabase Auth and a first owner account/admin grant have not been configured.
- Orders and design requests can be stored, but the owner-facing dashboard is not yet a working order-management interface.
- No payment gateway, shipping-rate integration, verified WhatsApp number, domain, or production deployment is configured.

## Security notes
- RLS is enabled on all commerce tables.
- Public product reads are limited to published products.
- Customer-facing RPCs are executable by `anon` only; authenticated execution has been revoked. They remain `SECURITY DEFINER` because public customers must be able to submit while direct table writes remain blocked. Keep their input validation and fixed `search_path`; add abuse/rate controls before public launch.
- Never put a Supabase `service_role` or secret key in frontend environment variables.

## Run locally
1. Install Node.js LTS and pnpm 10.
2. Run `pnpm install`.
3. Copy `.env.example` to `.env`.
4. Keep `VITE_STORE_CATALOG_CONFIRMED=false` and leave WhatsApp/email/Instagram blank until verified.
5. Run `pnpm dev:static` for the frontend preview, or `pnpm build:static` for a static build.

## Launch blockers
1. Replace illustrative sample products/prices with approved products, real photos, actual sizes/colors, production type and inventory.
2. Connect storefront catalog/cart/checkout to Supabase and remove local demo pricing from order creation.
3. Configure Supabase Auth, create the owner's account, and add that UUID to `admin_users`.
4. Build the real admin CRUD/orders/custom-design screens with RLS-backed access.
5. Confirm shipping zones, rates, delivery timelines, and returns/refunds wording under Egyptian consumer law.
6. Configure payment methods and the official customer-service channels.
7. Add CAPTCHA/rate limiting/abuse protection to public RPC endpoints, then re-run Supabase advisors and end-to-end tests.
