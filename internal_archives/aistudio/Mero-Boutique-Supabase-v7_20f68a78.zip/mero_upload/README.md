# Mero Boutique

A bilingual (Arabic/English), responsive boutique storefront built with React, TypeScript, Vite, Express, tRPC and Drizzle. The current delivery is a **pre-launch Supabase-connected storefront**: the public catalog, product detail pages, cart calculations, order submission and custom-design requests use the live Supabase project. Cart and wishlist remain browser-local.

## Requirements

- Node.js 22+
- pnpm 10.18+

## Local development

```bash
cp .env.example .env
pnpm install --frozen-lockfile
pnpm dev
```

Keep `VITE_STORE_CATALOG_CONFIRMED=false` until the products, prices and stock are verified. Checkout records the order in Supabase; WhatsApp is an optional handoff after the save. Set `VITE_STORE_WHATSAPP_NUMBER` to the official WhatsApp Business number in international digits-only format (Egypt example: `2010XXXXXXXXX`). Set contact email and Instagram only to real accounts.

## Quality commands

```bash
pnpm check
pnpm test
pnpm build
pnpm start
```

## Deployment

The included Dockerfile builds and starts the Express server. Pass the four `VITE_STORE_*` public storefront values as Docker build args (they are embedded into the frontend bundle). Configure the required runtime environment variables in the hosting provider. `DATABASE_URL`, `MANUS_PROJECT_ID`, `MANUS_JWT_SECRET`, `MANUS_OAUTH_API_URL`, and any required Manus API settings are needed only for the included platform auth/API functionality. Keep secrets server-side; never prefix secrets with `VITE_`.

For a static storefront build, run `pnpm build:static`; the output is `dist/public`. Static hosting does not include Express/tRPC APIs or working admin authentication. Configure an SPA fallback to `/index.html`.

## Important launch limitations

Read [PRE-LAUNCH.md](./PRE-LAUNCH.md) before making the site public. The uploaded ZIP did not contain verified commercial data or real product photography. No sample prices/products are seeded. Local SVG illustrations are temporary. A live Supabase schema stores orders and custom-design requests; a full visual admin CRUD console, card gateway and automatic shipping calculation are still not implemented. The boutique must confirm shipping and fulfillment manually.

### Custom design requests
The storefront includes a dedicated custom-design request page at `/custom-design`, linked from the main navigation and homepage. It gathers the customer's design brief and routes the inquiry to the boutique's configured WhatsApp number. Custom production terms displayed on the page specify a 30% deposit after design/material/price approval, with the balance due on delivery. Configure `VITE_STORE_WHATSAPP_NUMBER` before enabling customer inquiries.


## Customer-facing policies
Independent Arabic/English policy pages are available at `/policies/shipping`, `/policies/returns`, `/policies/custom-orders`, `/policies/payment`, `/policies/privacy`, and `/policies/terms`. Checkout and custom-design inquiries require policy acknowledgement before continuing to WhatsApp. These are operational drafts and should be reviewed by Egyptian counsel before public launch.


## Supabase commerce backend

A Supabase project named `mero-boutique` has been created in Frankfurt (EU Central), and the commerce schema has been applied. See [`supabase/README.md`](./supabase/README.md) and the migration in [`supabase/migrations`](./supabase/migrations).

The public catalog and checkout now use Supabase when `VITE_SUPABASE_URL` and `VITE_SUPABASE_PUBLISHABLE_KEY` are configured. The browser publishable key is intended for client use; never add a Supabase secret or `service_role` key to Vite variables.

Before the admin dashboard can be activated, create the owner's Supabase Auth user and add its UUID to `public.admin_users` as described in `supabase/README.md`.

## Owner administration
The `/admin` route now includes Supabase Auth sign-in and an owner-only console for product creation/editing/deletion, order review/status updates, and custom-design request review/status updates. Access is verified against `public.admin_users`; creating an Auth user alone does not grant store access. Follow `supabase/README.md` to allow-list the owner UUID. Product image URLs can be entered in the console; the `product-images` bucket is available for a future direct-upload enhancement.
