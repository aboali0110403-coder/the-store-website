# Mero Boutique — Implementation Plan

## Product scope

Mero Boutique is a premium Egyptian fashion storefront for hand-embroidered and embroidery-inspired garments. The first implementation delivers a cohesive, responsive storefront with a production-oriented information architecture: homepage, catalog, product detail, wishlist, persisted shopping bag, checkout, order confirmation, customer support entry points, bilingual direction switching, and a protected admin entry point. The project remains ready to connect the catalog, orders, content and inventory views to the selected managed database and Manus OAuth session.

## Implementation approach

- **Frontend:** React + TypeScript + Wouter, with a shared `SiteShell`, reusable commerce cards, client-side catalog data, and localStorage-backed cart/wishlist state so browsing and checkout interactions work in Preview without fake buttons.
- **Commerce routes:** `/`, `/shop`, `/shop/:slug`, `/checkout`, `/order-confirmation`, `/our-story`, `/admin`, and `/404` are declared in the route manifest and registered unconditionally.
- **Data model:** Catalog records are centralized in `client/src/lib/store.ts` with explicit fields for price, category, sizes, colors, production method, stock state and imagery. Cart and wishlist persistence is isolated behind small helpers so the UI can be migrated to database-backed tRPC procedures without rewriting components.
- **Admin boundary:** `/admin` uses the starter's real Manus OAuth query and login helper. Signed-out visitors see an authenticated entry state instead of a fabricated dashboard. Authenticated owners receive a structured dashboard shell for products, orders, content and analytics integration.
- **Backend readiness:** The existing Express/tRPC server and managed database remain enabled. The next persistence phase can add Drizzle tables for products, orders, reviews, content settings and governorate shipping rules without replacing the front end.
- **Quality:** Strict TypeScript diagnostics remain host-managed; the app exposes `/api/health` and `public/manus-routes.json`, uses semantic controls and labels, avoids invented statistics/testimonials/offers, and keeps all responsive layouts within the supplied palette.

## Design direction

### Style candidates

- Editorial atelier minimalism — **0.06**
- Romantic maximalist couture — **0.04**
- Contemporary desert gallery — **0.08**

**Chosen direction: Editorial atelier minimalism.** It treats embroidery as art object and gives garments room to breathe, balancing Egyptian craft references with a quiet contemporary boutique mood.

- **Design movement:** Modern editorial fashion / atelier minimalism with restrained Oriental craft references.
- **Core principles:** quiet confidence, tactile materiality, asymmetrical editorial rhythm, and deliberate whitespace.
- **Color philosophy:** warm ivory holds the page like textured paper; rose and mauve soften the visual field; deep burgundy anchors trust and purchase actions; champagne gold appears only as a fine stitch-like accent.
- **Layout paradigm:** split hero, offset editorial blocks, generous vertical pacing, and horizontal collection rails instead of a dense centered template grid.
- **Signature elements:** thin gold stitch rules, circular category portraits, and a small rose-mauve dot motif that echoes embroidery without becoming literal decoration.
- **Interaction philosophy:** interactions are quiet and tactile: underlines grow, cards lift slightly, and purchase actions use confident burgundy surfaces. No gratuitous motion.
- **Animation:** 180–260ms ease-out transitions for hover, wishlist, filters and drawer states; hero imagery remains calm; respect reduced-motion preferences.
- **Typography system:** Cormorant Garamond for the MERO wordmark and major display lines, Playfair Display for selected editorial statements, Inter for English controls, and system Arabic fallback with RTL-safe metrics when Arabic is selected.
- **Brand essence:** Exclusive Egyptian designer garments where embroidery heritage becomes modern self-expression. Personality: artistic, poised, intimate.
- **Brand voice:** concise, sensory, and assured. Example lines: “Wear art. Celebrate craftsmanship.” / “Every stitch carries a story.”
- **Wordmark & logo:** stacked typographic wordmark with large MERO, tracked BOUTIQUE beneath, and a circular M monogram for compact contexts.
- **Signature brand color:** Deep Burgundy `#49343F`, used as the unmistakable anchor for calls to action, stat bands, and footer.

## Project structure

- `client/src/App.tsx` — route map and global providers.
- `client/src/components/SiteShell.tsx` — announcement bar, sticky navigation, cart drawer, footer and language direction.
- `client/src/lib/store.ts` — catalog data, bilingual copy, cart/wishlist persistence and commerce types.
- `client/src/pages/Home.tsx` — editorial homepage sections and newsletter interaction.
- `client/src/pages/Shop.tsx` — catalog filtering, sorting and product cards.
- `client/src/pages/ProductDetail.tsx` — product gallery, size/color/production details and add-to-bag flow.
- `client/src/pages/Checkout.tsx` — validated customer details form and order summary.
- `client/src/pages/OrderConfirmation.tsx` — confirmation state and reference number.
- `client/src/pages/Story.tsx` — craft narrative and production-method distinctions.
- `client/src/pages/Admin.tsx` — authenticated admin entry/dashboard shell.
- `client/src/index.css` — palette, typography, layout primitives and responsive rules.
- `public/manus-routes.json` — crawlable route declarations.
- `server/*`, `drizzle/*` — managed server, OAuth and database foundations preserved for persistence wiring.
