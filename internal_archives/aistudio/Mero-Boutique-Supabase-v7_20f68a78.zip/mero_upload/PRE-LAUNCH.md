# Mero Boutique — launch readiness

## What is connected now

- Public storefront catalog reads published products from the live Supabase `products` table.
- Product details, search/filtering, wishlist/cart display and checkout use the database-backed catalog; the former invented sample prices and sample products have been removed from storefront data.
- Checkout validates the cart against live product IDs and submits the order through `submit_store_order`. The database calculates prices from the current product records and stores order + item snapshots atomically. WhatsApp opens afterward only if an official number is configured.
- Custom-design inquiries are saved through `submit_custom_design_request` when Supabase is configured.
- Anonymous database grants have been narrowed to read-only access to `products`; customer submissions go through the validated RPC functions.

## Still required before accepting public sales

1. Add real product records to `public.products`: accurate Arabic/English names, descriptions, category, EGP price, actual photos, sizes, colors, fabric, embroidery method, production type, stock and publication state. No sample catalog is seeded.
2. Replace temporary SVG illustration assets with photographs of the actual garments. The homepage editorial images remain clearly illustrative.
3. Create the owner's Supabase Auth user and add its UUID to `public.admin_users` using the instructions in `supabase/README.md`. The legacy Manus admin shell is not a finished Supabase admin dashboard; do not rely on it for catalog/order management yet.
4. Configure `VITE_STORE_WHATSAPP_NUMBER` and real contact channels. Keep `VITE_STORE_CATALOG_CONFIRMED=false` until every listing and stock count is reviewed. Without the WhatsApp number, orders are still saved in Supabase and shown as a success confirmation, but no WhatsApp handoff occurs.
5. Confirm delivery coverage and fees for all governorates; shipping and final payable amount are not automatically calculated.
6. Test real order submission, stock decrement, duplicate/abusive submissions, cancellation/refund and fulfillment workflows in a controlled environment.
7. Add CAPTCHA and rate limiting to the public order/design RPCs before promoting the site publicly. Supabase security advisor currently warns that these public SECURITY DEFINER functions are callable by anonymous visitors by design.
8. Have Egyptian counsel review returns, privacy, custom-order, tax/invoice, business identity and consumer-protection disclosures before launch.
9. Confirm rights to the Mero Boutique name, logo, photography and all design assets.

## Current operational limits

- No card gateway or online payment collection is implemented. Orders currently record cash-on-delivery as the selected payment method.
- Shipping fees are not calculated; staff must confirm them.
- A production-ready Supabase admin interface for product CRUD, order fulfillment, and custom-design request management is not yet complete.
- The 30% custom-design deposit is a request/business term recorded on the request; no online deposit collection is implemented.

## Build and deploy

- Node.js 22+ and pnpm 10.18+.
- `pnpm install --frozen-lockfile`
- `pnpm check`
- `pnpm test`
- `pnpm build:static` for a static storefront; output: `dist/public`.
- Supply `VITE_SUPABASE_URL`, `VITE_SUPABASE_PUBLISHABLE_KEY`, `VITE_STORE_WHATSAPP_NUMBER`, `VITE_STORE_CATALOG_CONFIRMED`, `VITE_STORE_CONTACT_EMAIL`, and `VITE_STORE_INSTAGRAM_URL` as build-time environment variables.
- Never expose Supabase secret/service-role keys in browser variables.

## Owner console readiness
- [ ] Create the owner account in Supabase Authentication.
- [ ] Add only the owner's Auth UUID to `public.admin_users`.
- [ ] Sign in at `/admin` and confirm product, order, and custom-request screens load.
- [ ] Add verified product photos, descriptions, sizes, stock, and prices; keep products unpublished until reviewed.
- [ ] Test a draft product, publish it, then verify it appears in the storefront.
