# Mero Boutique — Supabase

Project ref: `pvvsvxdqjguemptocvcs`  
Region: `eu-central-1` (Frankfurt)  
Project URL: `https://pvvsvxdqjguemptocvcs.supabase.co`

## Live schema

- `products`: bilingual catalog, EGP prices, stock and publication state.
- `orders` + `order_items`: customer order details and database-calculated price snapshots.
- `custom_design_requests`: bespoke requests and 30% deposit rate.
- `admin_users`: owner/admin allow-list.
- `product-images`: public-read image bucket; uploads/changes are restricted to admins.

## Owner bootstrap

1. In Supabase Dashboard → Authentication → Users, create the owner's account.
2. Copy the user's UUID.
3. In SQL Editor, run:

```sql
insert into public.admin_users(user_id)
values ('PASTE_OWNER_AUTH_USER_UUID_HERE')
on conflict (user_id) do nothing;
```

Never expose a Supabase `service_role` or secret key in the website. Only the publishable key belongs in `VITE_SUPABASE_PUBLISHABLE_KEY`.

## Storefront integration

The frontend reads `products` using the public read-only Data API. The product catalog, detail page, cart calculations and checkout now use the live database catalog. `submit_store_order` and `submit_custom_design_request` are public RPC entry points with server-side validation. Order prices are taken from the database, not the browser.

Anonymous table grants have been restricted to `SELECT` on `products`; all other public table access is denied. RLS remains enabled. The two public RPC functions intentionally retain anonymous execute permission so customers can submit orders/design requests without creating accounts. This produces Supabase security-advisor warnings; implement CAPTCHA/rate limiting before public marketing.

No product data was seeded because the earlier sample products/prices and generated illustrations were not verified commercial listings. Add real records only after confirming their details.
